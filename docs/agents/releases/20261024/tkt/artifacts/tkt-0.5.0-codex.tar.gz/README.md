# tkt

Git-native ticket tracker and workflow skills (tkt-core, tkt-orient, tkt-work, tkt-reconcile): track tasks as markdown files in .tickets/ and work the dependency-graph frontier. Requires the tkt CLI on PATH.

This codex plugin archive contains version 0.5.0, with 4 workflow skills and their supporting resources. It was built from commit 2b6ff173993c9fe413c40287fb1cb3f0a9879ca1.

## Install

Extract this archive into its own directory, then use the host's native plugin installer:

```sh
codex plugin marketplace add /absolute/path/to/extracted-plugin
codex plugin add tkt@tkt
```

Restart or reload the host after installing. Read each bundled SKILL.md for workflow-specific prerequisites; install any required command-line tools separately. This archive supplies skills and references, not third-party executables. Retain all bundled license and attribution notices when redistributing it.

## Maintainer helpers

Bundled maintenance helpers need Node 22+, Git and their pinned Node dependencies. Run `npm ci --ignore-scripts` in a disposable extracted copy before invoking them. Preparation and product checks take an explicit --repo pointing to a clean Git checkout. Installing this plugin alone does not prepare or publish a release.
