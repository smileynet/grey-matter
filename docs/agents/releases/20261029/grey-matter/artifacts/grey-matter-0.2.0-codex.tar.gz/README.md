# grey-matter

Agent skills for game-centric and app development: engineering (build), productivity (think/communicate), and meta (tend the set). Start with the compass router.

This codex plugin archive contains version 0.2.0, with 48 workflow skills and their supporting resources. It was built from commit 05792a71c7e936b3ed26a623933bbfa224d7b93c.

## Install

Extract this archive into its own directory, then use the host's native plugin installer:

```sh
codex plugin marketplace add /absolute/path/to/extracted-plugin
codex plugin add grey-matter@grey-matter
```

Restart or reload the host after installing. Read each bundled SKILL.md for workflow-specific prerequisites; install any required command-line tools separately. This archive supplies skills and references, not third-party executables. Retain all bundled license and attribution notices when redistributing it.

## Maintainer helpers

Bundled maintenance helpers need Node 22+, Git and their pinned Node dependencies. Run `npm ci --ignore-scripts` in a disposable extracted copy before invoking them. Preparation and product checks take an explicit --repo pointing to a clean Git checkout. Installing this plugin alone does not prepare or publish a release.
