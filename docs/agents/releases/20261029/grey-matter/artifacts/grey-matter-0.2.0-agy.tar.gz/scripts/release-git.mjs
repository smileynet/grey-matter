// Scope every release Git operation to its explicit repository, including in hooks.
import { spawnSync } from "node:child_process";
import { ReleaseError } from "./release-version.mjs";

export function gitEnvironment(extra = {}) {
  const env = { ...process.env, GIT_OPTIONAL_LOCKS: "0", ...extra, GIT_NO_REPLACE_OBJECTS: "1" };
  for (const key of ["GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES"]) delete env[key];
  return env;
}

export function command(repo, args, options = {}) {
  const env = gitEnvironment(options.env);
  const result = spawnSync("git", ["-C", repo, ...args], { encoding: "utf8", maxBuffer: 32 * 1024 * 1024, ...options, env });
  if (result.error) throw result.error;
  return result;
}

export function git(repo, args, options) {
  const result = command(repo, args, options);
  if (result.status !== 0) throw new ReleaseError(`git ${args[0]} failed: ${result.stderr.toString().trim()}`);
  return result.stdout;
}

// Push sealed candidate refs and an optional checked development integration; stable follows later.
export function pushCandidateRefs({ repo, remote = "origin", branch, tag, candidateSha, tagObject, developmentSha, execute = false }) {
  if (typeof execute !== "boolean" || !/^[a-f0-9]{40}$/.test(candidateSha) || !/^[a-f0-9]{40}$/.test(tagObject)) throw new ReleaseError("invalid candidate ref identity or execution mode");
  for (const ref of [branch, tag]) {
    if (typeof ref !== "string" || !ref || ref.startsWith("-") || command(repo, ["check-ref-format", ref]).status !== 0) throw new ReleaseError("invalid full release ref");
  }
  if (!branch.startsWith("refs/heads/") || branch === "refs/heads/stable" || !tag.startsWith("refs/tags/")) throw new ReleaseError("candidate push requires a branch other than stable and a tag");
  if (developmentSha !== undefined && (!/^[a-f0-9]{40}$/.test(developmentSha) || git(repo, ["cat-file", "-t", developmentSha]).trim() !== "commit" || command(repo, ["merge-base", "--is-ancestor", candidateSha, developmentSha]).status !== 0)) throw new ReleaseError("development integration must contain the exact candidate commit");
  const developmentRef = developmentSha === undefined ? [] : ["refs/heads/main"];
  if (developmentSha !== undefined && branch === "refs/heads/main") throw new ReleaseError("candidate branch must be distinct from development main");
  const url = pushUrl(repo, remote);
  requireCandidateTag({ repo, candidateSha, tagObject, tag });
  function inspect() {
    const refs = new Map(git(repo, ["ls-remote", "--refs", url, branch, tag, ...developmentRef]).trim().split("\n").filter(Boolean).map((line) => {
      const fields = line.split(/\s+/);
      if (fields.length !== 2 || !/^[a-f0-9]{40}$/.test(fields[0]) || ![branch, tag, ...developmentRef].includes(fields[1])) throw new ReleaseError("invalid remote ref response");
      return [fields[1], fields[0]];
    }));
    if (refs.has(tag) && refs.get(tag) !== tagObject) throw new ReleaseError("remote release tag differs; refusing replacement");
    const old = refs.get(branch);
    if (old && old !== candidateSha && command(repo, ["merge-base", "--is-ancestor", old, candidateSha]).status !== 0) throw new ReleaseError("remote candidate branch is divergent or ancestry is unavailable");
    const main = refs.get("refs/heads/main");
    if (developmentSha !== undefined && (!main || (main !== developmentSha && command(repo, ["merge-base", "--is-ancestor", main, developmentSha]).status !== 0))) throw new ReleaseError("development main is missing, divergent or advanced beyond the verified integration; fetch and recheck it");
    return { branch: old ?? null, tag: refs.get(tag) ?? null, ...(developmentSha === undefined ? {} : { development: main }) };
  }
  let observed = inspect();
  const matches = () => observed.branch === candidateSha && observed.tag === tagObject && (developmentSha === undefined || observed.development === developmentSha);
  if (execute && !matches()) {
    const push = command(repo, ["-c", "push.followTags=false", "push", "--atomic", "--no-follow-tags", "--recurse-submodules=no", url, `${candidateSha}:${branch}`, `${tagObject}:${tag}`, ...(developmentSha === undefined ? [] : [`${developmentSha}:refs/heads/main`])]);
    observed = inspect();
    if (!matches()) throw new ReleaseError(`atomic candidate push was not observed (exit ${push.status}); inspect and resume the same identity; no sequential fallback`);
  }
  return { status: "pass", mode: execute ? "candidate-push" : "dry-run", complete: matches(), refs: observed };
}

function pushUrl(repo, remote) {
  if (typeof remote !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(remote)) throw new ReleaseError("invalid remote name");
  const urls = git(repo, ["remote", "get-url", "--push", "--all", remote]).trim().split("\n");
  if (urls.length !== 1 || !urls[0] || urls[0].startsWith("-")) throw new ReleaseError("candidate push requires exactly one push URL");
  return urls[0];
}

// This transport primitive must be called only after publication gates are checked.
export function pushStableRef({ repo, remote = "origin", candidateSha, execute = false }) {
  if (typeof execute !== "boolean" || !/^[a-f0-9]{40}$/.test(candidateSha) || git(repo, ["cat-file", "-t", candidateSha]).trim() !== "commit") throw new ReleaseError("invalid stable identity or execution mode");
  const url = pushUrl(repo, remote), ref = "refs/heads/stable";
  function inspect() {
    const lines = git(repo, ["ls-remote", "--refs", url, ref]).trim().split("\n").filter(Boolean);
    if (lines.length > 1) throw new ReleaseError("duplicate stable ref response");
    if (!lines.length) return null;
    const [sha, name, extra] = lines[0].split(/\s+/);
    if (extra || name !== ref || !/^[a-f0-9]{40}$/.test(sha)) throw new ReleaseError("invalid stable ref response");
    if (sha !== candidateSha && command(repo, ["merge-base", "--is-ancestor", sha, candidateSha]).status !== 0) throw new ReleaseError("stable is divergent or ancestry is unavailable; refusing to force");
    return sha;
  }
  let observed = inspect();
  if (execute && observed !== candidateSha) {
    let failure;
    try {
      const pushed = command(repo, ["push", "--atomic", "--no-follow-tags", "--recurse-submodules=no", url, `${candidateSha}:${ref}`]);
      if (pushed.status !== 0) failure = `exit ${pushed.status}`;
    } catch (error) { failure = error.message; }
    observed = inspect();
    if (observed !== candidateSha) throw new ReleaseError(`stable promotion was not observed${failure ? ` (${failure})` : ""}; resume promotion without publishing again`);
  }
  return { status: "pass", mode: execute ? "stable-promotion" : "dry-run", complete: observed === candidateSha, sha: observed };
}

// Compare the effective push URL, including Git's pushInsteadOf expansion.
export function requireGithubRemote({ repo, repository, remote = "origin" }) {
  if (typeof repository !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_.-]*\/[A-Za-z0-9][A-Za-z0-9_.-]*$/.test(repository)) throw new ReleaseError("invalid reviewed GitHub repository");
  const url = pushUrl(repo, remote);
  let path;
  const scp = /^git@github\.com:([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)$/.exec(url);
  if (scp) path = scp[1];
  else {
    let parsed;
    try { parsed = new URL(url); }
    catch { throw new ReleaseError("release remote must use GitHub.com HTTPS or Git SSH"); }
    const https = parsed.protocol === "https:" && !parsed.username && !parsed.password && (!parsed.port || parsed.port === "443");
    const ssh = parsed.protocol === "ssh:" && parsed.username === "git" && !parsed.password && (!parsed.port || parsed.port === "22");
    if (parsed.hostname !== "github.com" || parsed.search || parsed.hash || (!https && !ssh)) throw new ReleaseError("release remote must use GitHub.com HTTPS or Git SSH");
    path = parsed.pathname.slice(1);
  }
  const name = path.replace(/\.git$/, "");
  if (name.toLowerCase() !== repository.toLowerCase()) throw new ReleaseError("effective push remote differs from reviewed GitHub repository");
  return { repository, remote, status: "pass" };
}

export function requireCandidateTag({ repo, candidateSha, tagObject, tag }) {
  if (!/^[a-f0-9]{40}$/.test(candidateSha) || !/^[a-f0-9]{40}$/.test(tagObject) || typeof tag !== "string" || !tag.startsWith("refs/tags/")) throw new ReleaseError("invalid annotated tag identity");
  if (git(repo, ["cat-file", "-t", candidateSha]).trim() !== "commit" || git(repo, ["cat-file", "-t", tagObject]).trim() !== "tag" || git(repo, ["rev-parse", `${tagObject}^{commit}`]).trim() !== candidateSha) throw new ReleaseError("annotated tag does not resolve to candidate commit");
  const header = git(repo, ["cat-file", "-p", tagObject]).split("\n\n", 1)[0].split("\n");
  if (!header.includes(`object ${candidateSha}`) || !header.includes("type commit") || !header.includes(`tag ${tag.slice("refs/tags/".length)}`)) throw new ReleaseError("annotated tag header differs from release identity");
}
