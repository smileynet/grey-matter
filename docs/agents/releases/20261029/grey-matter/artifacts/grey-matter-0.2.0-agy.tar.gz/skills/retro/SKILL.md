---
name: retro
description: "Conduct a retrospective on a coding session: read it from a fresh context and propose environment fixes (checks, guardrails, steering), classified mechanical vs judgement. Use when a session ends, after a build that went sideways, or when wrap-session reaches its retro step."
---

The user has asked for a **retrospective**. You are suggesting improvements to the coding agent's **environment** to improve future runs.

## Steps

1. Call the Skill tool with `writing-for-agents` for the writing style guide.

2. Read the primary sources for the session the user specifies (default: the current one). This may mean searching session logs on this machine; where logs aren't reachable, work from the session the user points at. **Read the session from a fresh context: dispatch a subagent to analyse the trace and report candidates.** An agent grading its own session is biased and blind to what it never logged; a fresh-context subagent, and leaning on deterministic checks over self-report, counters that. (A shell-invoked fresh agent via the harness CLI is an alternative, spiked separately.)

3. Look for candidates for improvement in these categories.

- **Navigation**: how easy was it for the agent to find the right files? Are there hidden dependencies between files? Would a **navigation pointer** make it easier? _Use when_ the session took a long time to find a piece of information.
- **Automated checks**: are there automated checks that could catch errors the agent made? Linting, typing, tests, filesystem linters? Read the repo's own check command first (its `package.json`/build-tool `lint`/`check` scripts, its CI workflow), so a check that already exists but sits unwired or silently broken is the finding, not a reinvention. A repo with no **guardrail** (no pre-commit hook and no CI job running its lint/typecheck/test command) is itself a finding: an un-linted repo is a standing missed opportunity, not a neutral default. _Use when_ the agent made a mistake an automated check could have caught, or the repo has no guardrail at all.
- **Coding standards**: should the **reviewer agent** be given a new rule to enforce? Should an existing rule be removed or clarified? Classify the violation first: a **mechanical** one (a fixed syntactic pattern, a banned API, an import shape, a file-location rule) gets a deterministic check, full stop: a custom rule in the repo's own linter, a new pre-commit hook, or a new CI job, whichever the repo's language and existing guardrail make cheapest. Default to building the check over writing the rule. Reserve `CODING_STANDARDS.md` for genuine **judgement calls** (cross-file consistency, "matches the surrounding style," anything no guardrail could ever substitute for). _Use when_ the reviewer agent failed to catch a mistake.
- **Global AGENTS.md**: are there any steering instructions that should be moved to coding standards (or automated checks) instead? _Use when_ the AGENTS.md file is particularly large, in the repo OR the user's global scope.
- **Tool economy**: did the agent make expensive tool calls that could be streamlined? Is there any custom tooling (CLI's, MCP's) that is particularly token-inefficient? _Use when_ the agent made an expensive tool call.
- **No-ops**: look for instructions in steering files that don't modify the agent's behavior. _Use when_ the steering files are large and unwieldy.
- **Information access**: look for opportunities to increase the agent's access to information. Teeing dev server logs, readonly access to third-party services. _Use when_ a crucial piece of information was not available to the agent.

4. Present these candidates to the user, in order of severity.

5. File the candidates the user accepts as tickets (see the issue-tracker doc). **First check existing tickets for overlap** (`tkt query`): when a candidate matches or extends an open ticket, update that ticket rather than filing a near-duplicate. Only genuinely new candidates become new tickets.

Retro grooms the **environment**. To groom the **ticket board** in the same session wrap-up (make open tickets current, capture untracked work, set the frontier ordering), pair this with `reconcile-tickets`. Both run at session *end*; `orient` is the session-*start* bookend that picks up where they leave off.

## Reference

### Implementation vs Review

Remember that all work goes through two stages: implementation and review. The implementation agent has the most **context pressure**. They are responsible for exploration, writing code, and debugging failures.

The review agent has the least context pressure, it receives a diff, so no exploration needed. It often does not need to write code or debug.

This means that the review agent should be responsible for imposing coding standards, not the implementation agent.

### Files

- `AGENTS.md`: the primary agent-instructions file, pushed to the context window of any agent working in this repo. Use it incredibly sparingly, usually only for **navigation pointers** to other files. `CLAUDE.md` just points to `AGENTS.md`, so every harness reads one source; keep the real content in `AGENTS.md`.
- `CODING_STANDARDS.md`: read during review, not implementation. Add **navigation pointers** to docs folders if the standards file gets more than 1,000 lines long.
- Docs: use docs as reference files, pointed to by other files. Look for existing docs before writing new ones.
- Skills: use skills for docs (since their description goes into the agent's context window), or for user-invoked commands. Follow the advice in the `writing-for-agents` skill.
