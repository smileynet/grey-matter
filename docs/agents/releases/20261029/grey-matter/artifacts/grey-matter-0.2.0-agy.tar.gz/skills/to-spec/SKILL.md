---
name: to-spec
description: "Turn the current conversation into a spec and publish it to the issue tracker: no interview, just synthesis of what you've already discussed."
disable-model-invocation: true
---

This skill takes the current conversation context and codebase understanding and produces a spec. Do NOT interview the user; just synthesize what you already know.

## Process

1. Explore the repo to understand the current state of the codebase, if you haven't already. Use the project's domain glossary vocabulary throughout the spec, and respect any ADRs in the area you're touching. For a game, the model vocabulary and the testing seams come from `game-native-design` and `game-modeling` (the deterministic sim core), not web-app assumptions; call the Skill tool with them if the project is a game.

2. Sketch out the seams at which you're going to test the feature. Existing seams should be preferred to new ones. Use the highest seam possible. If new seams are needed, propose them at the highest point you can. The fewer seams across the codebase, the better - the ideal number is one. (If you can't get the feature down to one or two high seams, that is design pressure: the module boundaries are probably wrong. Call the Skill tool with "codebase-design" before forcing it.)

Check with the user that these seams match their expectations.

3. Write the spec using the template below, then publish it: write the spec as a doc under `docs/` and record it on the tracker ticket as its spec-slug (see the issue-tracker doc). Mark it `triage:ready-for-agent` (the asserted "brief is complete" tag, distinct from `tkt ready`); no additional triage needed.

<spec-template>

## Problem Statement

The problem that the user is facing, from the user's perspective.

## Solution

The solution to the problem, from the user's perspective.

## User Stories

A long, numbered list of user stories, exhaustive over what the conversation and the codebase actually established. Each user story should be in the format of:

1. As an <actor>, I want a <feature>, so that <benefit>

<user-story-example>
1. As a mobile bank customer, I want to see balance on my accounts, so that I can make better informed decisions about my spending
</user-story-example>

Cover every aspect of the feature that was discussed. Each story must trace to something the user raised or the codebase shows: be exhaustive over the real material, never invent capability the user did not ask for. Length comes from a thorough grilling, not from padding.

## Implementation Decisions

A list of implementation decisions that were made. This can include:

- The modules that will be built/modified
- The interfaces of those modules that will be modified
- Technical clarifications from the developer
- Architectural decisions
- Schema changes
- API contracts
- Specific interactions

Do NOT include specific file paths or code snippets. They may end up being outdated very quickly.

Exception: if a prototype produced a snippet that encodes a decision more precisely than prose can (state machine, reducer, schema, type shape), inline it within the relevant decision and note briefly that it came from a prototype. Trim to the decision-rich parts, not a working demo, just the important bits.

## Testing Decisions

A list of testing decisions that were made. Include:

- A description of what makes a good test (only test external behavior, not implementation details)
- Which modules will be tested
- Prior art for the tests (i.e. similar types of tests in the codebase)

## Out of Scope

A description of the things that are out of scope for this spec.

## Further Notes

Any further notes about the feature.

</spec-template>
