# tkt Command Reference

## Agent eligibility

Identify each invocation with global `--agent <lowercase-slug>` or `TKT_AGENT`; the flag wins and identity is never stored in config. `ready` and `claim` apply ticket agent eligibility. Missing identity sees unrestricted work only; `ready` reports hidden restricted work on stderr. Use `claim <id> --force` only as an explicit scheduling override.

Create or replace eligibility with mutually exclusive `--agents codex,claude` or `--exclude-agents antigravity` on `new`, `batch`, and `edit`; `edit --agents ''` or `edit --exclude-agents ''` clears it. Frontmatter stores one optional signed `agents` list: `["codex", "claude"]` allows either, `["!antigravity"]` excludes that agent, omission allows everyone. Lists must be nonempty, homogeneous in sign, duplicate-free, and contain lowercase alphanumeric/hyphen slugs. Serialization sorts names. `ready` human/JSON and `query` JSON expose the policy (`agents: []` in JSON means unrestricted). `query` honors tag context but never filters by current agent. Tags scope work streams; `requires` remains all-of machine capabilities; eligibility is separate from ownership after claim.

## Task lifecycle

| Command | Effect |
|---------|--------|
| `tkt new <slug> --title "..." [--tags STREAM]` | Create task (defaults to `open`), assign ID, push |
| `tkt batch "slug:title" ...` | Create multiple tasks in one push |
| `tkt claim <id>` | Mark in-progress (push = visible WIP) |
| `tkt close <id> --resolution "..."` | Mark done, write resolution |
| `tkt edit <id> [--title] [--priority] [--blocked-by] [--status]` | Surgical field change |

## Viewing

| Command | Effect |
|---------|--------|
| `tkt ready` | Unblocked tasks sorted by priority |
| `tkt ready --json` | JSON Lines output |
| `tkt blocked` | Tasks with unsatisfied dependencies |
| `tkt query` | All tasks as JSON Lines |
| `tkt query --status open --priority high` | Filtered view |

## Health and maintenance

| Command | Effect |
|---------|--------|
| `tkt validate` | Contract integrity: cycles, broken deps, invalid fields, decay |
| `tkt validate --strict` | Warnings become errors |
| `tkt validate --brief` | Human-readable summary |
| `tkt validate --fix` | Auto-repair fixable problems (quoting, field cleanup, blocked_by ref normalization); aborts if a repair would introduce a new finding |
| `tkt validate --fix --dry-run` | Preview what --fix would change |
| `tkt audit` | Closure quality: unchecked ACs, TBD resolutions, stale WIP |
| `tkt audit --strict` | Treat warnings as errors |
| `tkt audit --brief` | Short summary |
| `tkt sync-plan [PLAN]` | Report ticket-vs-plan drift (advisory, exit 0; default: docs/plan.md) |
| `tkt sync-plan --check [PLAN]` | CI gate: exit 1 on drift |
| `tkt sync-plan --fix [--dry-run] [PLAN]` | Update status cells and append missing tickets under Unplanned tickets (`--dry-run` previews) |
| `tkt lint` | Normalize frontmatter style (quoting, field order, blocked_by id padding + slug refs) |
| `tkt lint --check` | CI mode: exit 1 if anything would change |
| `tkt lint 03 07` | Lint specific tickets only |
| `tkt doctor` | Verify current project setup |
| `tkt doctor <path>` | Scan all projects, flag issues |
| `tkt doctor --strict` | Strict mode |

## Other commands

| Command | Job | When to use |
|---------|-----|-------------|
| `tkt renumber <old> <new>` | Move ticket to new ID | Only during birth window (before ID is cited elsewhere) |
| `tkt rebase` | Resolve ID collisions with upstream | After `git pull` introduces conflicts |
| `tkt config --list` | Show project configuration | Checking what gates are active |
| `tkt config --set key=value` | Set config value | Changing close requirements, push behavior |
| `tkt config --show` | Show resolved values with sources | Debugging config cascade |
| `tkt telemetry --status` | Check telemetry state | Privacy audit |
| `tkt telemetry --enable` / `--disable` | Toggle telemetry consent | Opt in/out |
| `tkt capabilities` | JSON feature manifest | Agent/automation discovery |
| `tkt init` | Initialize `.tickets/` and deploy agent integration files | New project setup |
| `tkt init --write` | Write agent snippet into AGENTS.md using markers | Embedding instructions |
| `tkt init --write FILE` | Write snippet to a specific file | Custom agent file |
| `tkt init --agent-only` | Output agent snippet only (skip dir/config creation) | Existing projects |

## Context (tag scoping)

| Command | Effect |
|---------|--------|
| `tkt context` | Show active context (include/exclude tags) |
| `tkt context backend api` | Set context: include backend + api tags |
| `tkt context +backend -frontend` | Include backend, exclude frontend |
| `tkt context --clear` | Clear active context |

When a context is active:
- `tkt new` and `tkt batch` auto-apply include-tags to new tickets
- `tkt ready`, `tkt query`, and `tkt blocked` filter results to matching tickets
- Tags use AND logic: ticket must have ALL include-tags and NONE of the exclude-tags

## Migration

| Command | Effect |
|---------|--------|
| `tkt migrate --detect` | Report detected ticket format and confidence |
| `tkt migrate --from tk --dry-run` | Preview migration without writing |
| `tkt migrate --from tk --confirm` | Apply the reviewed tk-format migration |

## Creation flags (new, batch)

| Flag | Effect | Default |
|------|--------|---------|
| `--title "..."` | Human-readable title | Required |
| `--status S` | `open` (default), `backlog` (deferred out of cycle), `in_progress`, `done` | `open` |
| `--priority P` | `urgent`, `high`, `medium`, `low` | `medium` |
| `--blocked-by N,N` | IDs that must be done first | none |
| `--env E` | Environment filter (`corp`, `personal`) | none |
| `--spec S` | Originating spec slug | none |
| `--tags T,T` | Work-stream / categorization tags — the primary scoping mechanism for `ready`/`context`. Set at creation (one tag is the norm in multi-stream projects); also auto-applied from active context. NOTE: `tkt edit` has NO `--tags` flag — to retag an existing ticket, edit its frontmatter `tags:` line directly (or set at creation / via `tkt context`). | none |
| `--validation "..."` | Validation criteria (repeatable). Alias: `--vc` | none |
| `--requires R,R` | Machine capabilities required (e.g., `gpu,linux,corp`) | none |

**After creation:** replace the generated `TBD` body and acceptance placeholders
before validating an open ticket; otherwise `stub-body` warns. Creation has no
`--body` or `--body-file` flag. Do not hide actionable work in backlog to silence it.

## Edit flags

| Flag | Effect |
|------|--------|
| `--title "..."` | Change title |
| `--status S` | Change status (`open`, `backlog`, `in_progress`). For `done`, use `tkt close` — editing status to `done` bypasses the close gates and is flagged by validate |
| `--priority P` | Change priority (pass `''` to clear) |
| `--blocked-by N,N` | Replace dependencies |
| `--env E` | Set environment (pass `''` to clear) |
| `--spec S` | Set spec link (pass `''` to clear) |
| `--ac N,N` | Check acceptance criteria boxes (1-based) |
| `--validation "..."` | Replace validation criteria list. Alias: `--vc` |

**Dependency edits replace:** `--blocked-by` replaces the entire list. To add a
blocker, read the current IDs, combine them with the addition, and pass the full set.
There are no `--add-blocked-by` or `--remove-blocked-by` flags.

## Close flags

| Flag | Effect |
|------|--------|
| `--resolution "..."` | What was done (alias: `--note`) |
| `--check-all` | Check all acceptance criteria boxes |
| `--ac 1,2` | Check specific AC boxes (1-based) |
| `--evidence "..."` | Proof per validation criterion (repeatable, positional) |
| `--force` | Close even with unchecked ACs |

## Global flags (all commands)

| Flag | Effect |
|------|--------|
| `--dry-run` | Preview mutations without writing |
| `-q` / `--quiet` | Suppress confirmations, emit only essential data |
| `-o json` | Structured JSON output (data to stdout, errors to stderr) |
| `--color always\|never\|auto` | Control ANSI color (default: auto) |

## Enforcement config (.tickets/config.toml)

These settings control what `tkt close` requires:

| Section.Key | Values | Effect |
|-------------|--------|--------|
| `close.require_resolution` | `true` / `false` | Must provide `--resolution` or `--note` |
| `close.require_checked_acs` | `true` / `false` | All ACs must be checked (default: true) |
| `close.require_validation_criteria` | `true` / `false` | Ticket must have `validation_criteria` field |
| `close.require_validation_evidence` | `"true"` / `"warn"` / `"false"` | Must provide `--evidence` per criterion |
| `close.allow_force` | `true` / `false` | Whether `--force` escape hatch is allowed |
| `push.enabled` | `true` / `false` | Mutations push to remote (default: true) |
| `validate.strict` | `true` / `false` | Warnings become errors |
| `ready.default_env` | string | Default CREW_ENV filter for `tkt ready` |
| `new.default_priority` | priority enum | Default priority for new tickets |
| `machine.capabilities` | comma-separated string | Capabilities this workstation provides (matched against ticket `requires` field) |

Manage with `tkt config --set close.require_resolution=true` or edit `.tickets/config.toml` directly.
