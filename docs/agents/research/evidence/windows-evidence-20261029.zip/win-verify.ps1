$PSStyle.OutputRendering = "PlainText"
$ErrorActionPreference = "Continue"
$nodeDir = "C:\Users\uosmi\AppData\Local\mise\installs\node\22.23.1"
$miseDir = "C:\Users\uosmi\AppData\Local\Microsoft\WinGet\Packages\jdx.mise_Microsoft.Winget.Source_8wekyb3d8bbwe\mise\bin"
$env:PATH = "$nodeDir;$miseDir;$env:PATH"
$node = "$nodeDir\node.exe"
$tools = "D:\code\windows-pinned-tools"
$R = "D:\code\release-20261028"
$pinned = @("--codex", "$tools\codex\bin\codex.exe", "--claude", "$tools\claude.exe", "--agy", "$tools\agy-probe.exe")

foreach ($p in @(
    @{ name = "grey"; repo = "$R\grey-worktree"; sha = "05792a71c7e936b3ed26a623933bbfa224d7b93c"; entry = "scripts\release.mjs" },
    @{ name = "tkt"; repo = "$R\tkt-worktree"; sha = "a827bb6f264ad2ef73157fd8c0a471cb78e634fe"; entry = "tools\release.mjs" })) {
  Push-Location $p.repo
  & npm.cmd ci --ignore-scripts *> "$R\$($p.name)-npm.log"
  "$($p.name) npm exit=$LASTEXITCODE"
  "$($p.name) status: $(git status --porcelain | Measure-Object | Select-Object -ExpandProperty Count) changed"
  & $node $p.entry verify --repo $p.repo --sha $p.sha --artifacts "$R\$($p.name)-artifacts" --out "$R\$($p.name)-verify" @pinned --execute *> "$R\$($p.name)-verify.log"
  "$($p.name) verify exit=$LASTEXITCODE"
  Pop-Location
}
