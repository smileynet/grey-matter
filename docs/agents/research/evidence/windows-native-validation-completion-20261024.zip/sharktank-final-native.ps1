$ErrorActionPreference='Stop'
$env:PATH='C:\Users\uosmi\AppData\Local\mise\installs\node\22.23.1;' + $env:PATH
$env:AGY_CLI_DISABLE_AUTO_UPDATE='true'
$node='C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node.exe'
$codex='D:/code/windows-pinned-tools/codex/bin/codex.exe'
$claude='D:/code/windows-pinned-tools/claude.exe'
$agy='D:/code/windows-pinned-tools/agy-probe.exe'
& $node D:/code/grey-windows-candidate-e071b7b/scripts/release-native.mjs --artifacts D:/code/windows-grey-artifacts --out D:/code/sharktank-final-grey-native --execute --codex $codex --claude $claude --agy $agy
$greyExit=$LASTEXITCODE
& $node D:/code/tkt-windows-candidate-2b6ff17/tools/release-native.mjs --artifacts D:/code/windows-tkt-artifacts --out D:/code/sharktank-final-tkt-native --execute --codex $codex --claude $claude --agy $agy
if ($greyExit -ne 0 -or $LASTEXITCODE -ne 0) {exit 1}
