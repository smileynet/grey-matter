$ErrorActionPreference='Stop'
$env:PATH='C:\Users\uosmi\AppData\Local\mise\installs\node\22.23.1;D:\code\windows-pinned-tools\codex\bin;D:\code\windows-pinned-tools;' + $env:PATH
$env:DISABLE_UPDATES='1'
$env:AGY_CLI_DISABLE_AUTO_UPDATE='true'
& C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node.exe D:/code/grey-matter/scripts/deploy.mjs audit --json
exit $LASTEXITCODE
