$ErrorActionPreference = 'Stop'
$env:PATH = 'D:\code\windows-validation-tools;C:\Users\uosmi\AppData\Local\mise\installs\node\22.23.1;' + $env:PATH
& D:/code/windows-validation-tools/tkt.exe --version
& C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node.exe D:/code/grey-windows-candidate-e071b7b/scripts/release-product.mjs --repo D:/code/grey-windows-candidate-e071b7b --sha e071b7b03d02025dc1af6c3ff2c4f8369f777587 --out D:/code/sharktank-final-grey-product --execute
exit $LASTEXITCODE
