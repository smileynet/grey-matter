import assert from 'node:assert/strict';import {writeFileSync,mkdirSync,readFileSync,cpSync,rmSync,mkdtempSync,readdirSync} from 'node:fs';import {execFileSync,spawn} from 'node:child_process';import {createInterface} from 'node:readline';import {createHash} from 'node:crypto';
import {catalog} from './release-native-catalog-adapter.mjs';import {loadPack} from 'file:///D:/code/grey-matter/scripts/deploy.mjs';
const base='D:/code/sharktank-cleanup-20261024',workspace=base+'/workspace',home='C:/Users/uosmi';mkdirSync(workspace,{recursive:true});
const env={HOME:home,USERPROFILE:home,CODEX_HOME:home+'/.codex',CLAUDE_CONFIG_DIR:home+'/.claude',KIRO_HOME:home+'/.kiro',DISABLE_UPDATES:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',AGY_CLI_DISABLE_AUTO_UPDATE:'true',GEMINI_API_KEY:'catalog-probe-dummy-not-a-real-key',GOOGLE_GEMINI_BASE_URL:'http://127.0.0.1:9'};
for(const k of ['PATH','SystemRoot','WINDIR','COMSPEC','PATHEXT','TMP','TEMP','APPDATA','LOCALAPPDATA'])if(process.env[k])env[k]=process.env[k];
const expected=[...loadPack('D:/code/grey-matter').skills,...loadPack('D:/code/tkt').skills].map(s=>s.name).sort();
const report={...JSON.parse(readFileSync(base+'/live-catalogs.json','utf8')),status:'fail',scope:'Actual user-level skill roots in a neutral workspace; initialization/catalog controls only',expected,rows:[],modelRequests:0};
function check(harness,skills,extra={}){const counts=new Map();for(const s of skills)counts.set(s.name,[...(counts.get(s.name)||[]),s.path]);const duplicates=[...counts].filter(([,paths])=>paths.length>1);const managed=skills.filter(s=>expected.includes(s.name.replace(/^(grey-matter|tkt):/,'')));assert.deepEqual(managed.map(s=>s.name.replace(/^(grey-matter|tkt):/,'')).sort(),expected);assert.deepEqual(duplicates,[]);report.rows.push({harness,skills,managedCount:managed.length,total:skills.length,duplicates,...extra});writeFileSync(base+'/live-catalogs.json',JSON.stringify(report,null,2)+'\n');}
function run(binary,args,input){return execFileSync(binary,args,{env,cwd:workspace,input,encoding:'utf8',timeout:45000,maxBuffer:16*1024*1024});}
async function kiro(){const binary='D:/code/windows-pinned-tools/kiro-extracted/LocalApp/Kiro-Cli/kiro-cli.exe',child=spawn(binary,['acp'],{env,cwd:workspace,stdio:['pipe','pipe','pipe']});const lines=createInterface({input:child.stdout});let stderr='',prompts,session=false;child.stderr.on('data',d=>stderr+=d);
 try{return await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('ACP catalog timeout')),25000);child.once('error',reject);child.once('exit',code=>reject(Error('ACP exited '+code+': '+stderr)));const send=(id,method,params)=>child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');lines.on('line',line=>{const m=JSON.parse(line);if(m.error){clearTimeout(timer);reject(Error(JSON.stringify(m.error)));}if(m.id===0)send(1,'session/new',{cwd:workspace,mcpServers:[]});if(m.id===1)session=true;if(m.method==='_kiro.dev/commands/available'&&Array.isArray(m.params?.prompts))prompts=m.params.prompts;if(session&&prompts){clearTimeout(timer);resolve(prompts);}});send(0,'initialize',{protocolVersion:1,clientCapabilities:{},clientInfo:{name:'live-catalog-audit',version:'1'}});});}
 finally{lines.close();if(child.exitCode===null){const exited=new Promise(r=>child.once('exit',r));child.kill();await exited;}}
}
try{
 const inventory=JSON.parse(run('D:/code/windows-pinned-tools/agy-probe.exe',['plugin','list','--json']));
 const shadow=mkdtempSync(base+'/agy-shadow-');let agy;
 try {
  const plugins=shadow+'/.gemini/config/plugins';mkdirSync(plugins,{recursive:true});const fileProof=[];
  for(const entry of inventory.filter(p=>p.enabled)){
   cpSync(entry.path,plugins+'/'+entry.name,{recursive:true});
   for(const item of readdirSync(entry.path,{recursive:true,withFileTypes:true}).filter(e=>e.isFile())){const source=item.parentPath+'/'+item.name,relative=source.slice(entry.path.length+1),hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');assert.equal(hash(source),hash(plugins+'/'+entry.name+'/'+relative));fileProof.push({plugin:entry.name,path:relative,sha256:hash(source)});}
  }
  mkdirSync(shadow+'/.gemini/antigravity-cli',{recursive:true});writeFileSync(shadow+'/.gemini/antigravity-cli/settings.json','{"modelProvider":"gemini"}\n');
  agy=JSON.parse(execFileSync('D:/code/windows-pinned-tools/agy-probe.exe',['--output-format','json','--print','/skills'],{env:{...env,HOME:shadow,USERPROFILE:shadow,APPDATA:shadow+'/AppData/Roaming',LOCALAPPDATA:shadow+'/AppData/Local'},cwd:workspace,encoding:'utf8',timeout:30000,maxBuffer:16*1024*1024}));assert.equal(agy.num_turns,0);
  check('agy',agy.command.data.skills.map(({name,path,builtin,plugin})=>({name,path,builtin,plugin})),{modelTurns:0,installedInventory:inventory,fileProof,scope:'Native actual installed-plugin inventory plus byte-identical shadow catalog with disposable Gemini provider settings; live OAuth catalog requires login and was not completed.'});
 }finally{rmSync(shadow,{recursive:true,force:true,maxRetries:20,retryDelay:100});}
 const prompts=await kiro();check('kiro',prompts.filter(p=>p.serverName==='skill:config').map(p=>({name:p.name,path:p.uri??p.path??null})),{kiroHome:env.KIRO_HOME});
 report.status='pass';delete report.errors;
}catch(error){report.errors=[error.stack];process.exitCode=1;}
finally{report.probeSha256=createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex');writeFileSync(base+'/live-catalogs.json',JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({status:report.status,rows:report.rows.map(({harness,total,managedCount,duplicates})=>({harness,total,managedCount,duplicates})),errors:report.errors}));
