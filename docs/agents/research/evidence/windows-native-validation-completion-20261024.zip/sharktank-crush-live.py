import os
import hashlib
import http.client
import json
import sys
import pathlib
import shutil
import socket
import subprocess
import tempfile
import time
import uuid

root = pathlib.Path(tempfile.mkdtemp(prefix='crush-candidate-catalog-'))
home = pathlib.Path('C:/Users/uosmi')
project = root / 'workspace'
project.mkdir(parents=True)
env = {k:v for k,v in os.environ.items() if k.upper() in {'PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','TMP','TEMP'}}
env.update(HOME=str(home), USERPROFILE=str(home), APPDATA='C:/Users/uosmi/AppData/Roaming', LOCALAPPDATA='C:/Users/uosmi/AppData/Local')
for key, child in [('XDG_CONFIG_HOME', 'config'), ('XDG_DATA_HOME', 'data'), ('XDG_STATE_HOME', 'state'), ('XDG_CACHE_HOME', 'cache'), ('CRUSH_GLOBAL_CONFIG', 'global-config'), ('CRUSH_GLOBAL_DATA', 'global-data'), ('CRUSH_SKILLS_DIR', 'user-skills'), ('CRUSH_SOCKET', 'unused.sock')]:
    env[key] = str(root / child)
profile = '(version 1)(allow default)(deny network*)(allow network-outbound (remote ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))'
expected = ['foreign']
report = {'schema': 1, 'kind': 'crush-native-candidate-catalog', 'status': 'fail', 'checks': [], 'environment': env}
process = None
log = None
report['executionPlatform']='win32-x64'
report['scope']='Actual user skill roots; neutral owned workspace and empty provider config; no model requests'
report['isolation']={'homes':'actual user profile; provider configuration and server data disposable','credentials':'environment allowlist; no user configuration','network':'not-enforced'}
try:
    expected = [p.name for p in (home / '.claude/skills').iterdir() if (p/'SKILL.md').is_file()]
    reservation = socket.socket()
    reservation.bind(('127.0.0.1', 0))
    port = reservation.getsockname()[1]
    reservation.close()
    command = ['D:/code/windows-pinned-tools/crush/crush_0.98.1_Windows_x86_64/crush.exe', 'server', '--host', f'tcp://127.0.0.1:{port}', '--data-dir', str(root / 'server-data')]
    log = (root / 'server.log').open('w')
    process = subprocess.Popen(command, cwd=project, env=env, stdout=log, stderr=log)
    for _ in range(200):
        if process.poll() is not None:
            raise RuntimeError('server stopped before discovery')
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=.1):
                break
        except OSError:
            time.sleep(.05)
    def request(method, path, body=None):
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=10)
        connection.request(method, path, body=json.dumps(body) if body is not None else None, headers={'Content-Type': 'application/json'})
        response = connection.getresponse()
        data = json.loads(response.read())
        connection.close()
        if response.status != 200:
            raise RuntimeError(f'{method} {path}: HTTP {response.status}: {data}')
        report['checks'].append({'method': method, 'path': path, 'status': response.status})
        return data
    workspace = request('POST', '/v1/workspaces', {'path': str(project), 'data_dir': str(root / 'workspace-data'), 'client_id': str(uuid.uuid4())})
    catalog = request('GET', '/v1/workspaces/' + workspace['id'] + '/skills')
    report['observedCatalog'] = catalog
    report['expected'] = expected
    loaded = [s for s in catalog if s['source'] != 'builtin']
    assert sorted(s['name'] for s in loaded if s['name'] in expected) == sorted(expected)
    assert len(set(s['name'] for s in loaded)) == len(loaded)
    assert workspace['config'].get('providers', {}) == {}
    report.update(status='pass', catalog=loaded, modelRequests=0, credentialInputs=0, managedCount=50, version=subprocess.run(['D:/code/windows-pinned-tools/crush/crush_0.98.1_Windows_x86_64/crush.exe', '--version'], env=env, capture_output=True, text=True, check=True).stdout.strip())
except Exception as error:
    report['errors'] = [repr(error)]
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    if log is not None:
        log.close()
        report['serverLog'] = (root / 'server.log').read_text()
    report['probeSha256'] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
    pathlib.Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + '\n')
    shutil.rmtree(root)
print(json.dumps({'status': report['status'], 'skills': len(report.get('catalog', [])), 'errors': report.get('errors')}))
raise SystemExit(0 if report['status'] == 'pass' else 1)
