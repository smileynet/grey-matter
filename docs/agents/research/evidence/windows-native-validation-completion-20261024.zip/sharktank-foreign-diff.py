import pathlib,json,hashlib
p=pathlib.Path('D:/code/sharktank-cleanup-20261024/backup-manifest.json');rows=json.loads(p.read_text())['unownedBefore'];out=[]
for row in rows:
 f=pathlib.Path(row['path']);now=({'link':str(f.resolve())} if 'link' in row else {'sha256':hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None})
 if any(now[k]!=row[k] for k in now):out.append({'path':str(f),'before':row,'now':now})
print(json.dumps(out,indent=2))
