import subprocess,json,pathlib,hashlib,sys
base=pathlib.Path('D:/code/sharktank-cleanup-20261024');mode=sys.argv[1]
assert mode in ['dry-run','execute']
command=['powershell','-NoProfile','-File','D:/code/sharktank-deploy.ps1','-Mode',mode]
r=subprocess.run(command,capture_output=True,text=True)
backup=json.loads((base/'backup-manifest.json').read_text());checks=[]
for row in backup['unownedBefore']:
 p=pathlib.Path(row['path']);checks.append({'path':row['path'],'vendorManagedCache': '/.codex/skills/.system/' in row['path'].replace(chr(92),'/').lower(),'unchanged':str(p.resolve())==row['link'] if 'link' in row else p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']})
if not all(c['unchanged'] or c['vendorManagedCache'] for c in checks):
 print(json.dumps({'foreignChanges':[c for c in checks if not c['unchanged']]}));raise SystemExit(1)
if mode=='dry-run':
 for row in backup['managedFiles']:
  p=pathlib.Path(row['path']);assert str(p.resolve())==row['link'] if 'link' in row else hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
record={'schema':1,'mode':mode,'command':command,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'unownedPreserved':checks,'dryRunManagedUnchanged':mode=='dry-run'}
(base/(mode+'-receipt.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'exit':r.returncode,'unownedFilesPreserved':sum(not c['vendorManagedCache'] for c in checks),'vendorCacheChanges':sum(c['vendorManagedCache'] and not c['unchanged'] for c in checks),'dryRunManagedUnchanged':mode=='dry-run','stderr':r.stderr,'stdoutTail':r.stdout[-1500:]}));raise SystemExit(r.returncode)
