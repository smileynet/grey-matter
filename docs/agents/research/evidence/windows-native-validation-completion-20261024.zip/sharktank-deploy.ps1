param([string]$Mode='dry-run')
$ErrorActionPreference='Stop'
$env:PATH='C:\Users\uosmi\AppData\Local\mise\installs\node\22.23.1;D:\code\windows-pinned-tools\codex\bin;D:\code\windows-pinned-tools;' + $env:PATH
$env:DISABLE_UPDATES='1'
$env:AGY_CLI_DISABLE_AUTO_UPDATE='true'
$node='C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node.exe'
$extra=@()
if ($Mode -eq 'dry-run') {$extra=@('--dry-run')} elseif ($Mode -ne 'execute') {throw 'unknown mode'}
& $node D:/code/grey-matter/scripts/deploy.mjs @extra
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
& $node D:/code/tkt/tools/deploy.mjs @extra
exit $LASTEXITCODE
