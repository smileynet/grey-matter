import pathlib,json,hashlib,zipfile,subprocess
base=pathlib.Path('D:/code');proof=base/'sharktank-cleanup-20261024';paths=list(proof.glob('*.json'))
for folder in ['sharktank-final-grey-product','sharktank-final-tkt-product','sharktank-final-grey-native','sharktank-final-tkt-native']:
 paths.extend((base/folder).glob('*'))
for pattern in ['sharktank-*.ps1','sharktank-*.py','sharktank-*.mjs']:
 paths.extend(base.glob(pattern))
paths.extend([base/'sharktank-codex-before.json',base/'release-native-catalog-adapter.mjs'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'schema':1,'candidateShas':{'grey-matter':'e071b7b03d02025dc1af6c3ff2c4f8369f777587','tkt':'2b6ff173993c9fe413c40287fb1cb3f0a9879ca1'},'backups':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in proof.glob('*.zip')],'git':[]}
for name in ['grey-matter','tkt','grey-windows-candidate-e071b7b','tkt-windows-candidate-2b6ff17']:
 row={'path':str(base/name)}
 for key,args in [('head',['rev-parse','HEAD']),('status',['status','--porcelain=v1'])]:
  r=subprocess.run(['git','-C',str(base/name),*args],capture_output=True,text=True);row[key]={'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr};assert r.returncode==0 and (key!='status' or not r.stdout)
 record['git'].append(row)
(proof/'machine-final.json').write_text(json.dumps(record,indent=2)+'\n');paths.append(proof/'machine-final.json')
paths=sorted(set(p for p in paths if p.is_file()));manifest=[{'path':p.relative_to(base).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in paths]
with zipfile.ZipFile(base/'sharktank-final-validation-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(base).as_posix())
 z.writestr('member-manifest.json',json.dumps(manifest,indent=2)+'\n')
p=base/'sharktank-final-validation-evidence.zip';print(json.dumps({'files':len(paths)+1,'sha256':sha(p),'bytes':p.stat().st_size}))
