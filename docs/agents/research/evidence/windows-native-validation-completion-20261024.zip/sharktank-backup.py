import pathlib,json,zipfile,hashlib
home=pathlib.Path('C:/Users/uosmi'); roots=['.agents/skills','.codex/skills','.claude/skills','.kiro/skills']; out=pathlib.Path('D:/code/sharktank-cleanup-20261024');out.mkdir(exist_ok=False)
manifest=[];unowned=[]; owned_paths=[]
def files(root):
 for p in root.iterdir():
  if p.is_symlink() or p.is_junction():yield {'path':str(p),'link':str(p.resolve())};continue
  if p.is_dir():yield from files(p)
  elif p.is_file():yield {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
with zipfile.ZipFile(out/'managed-skills-before.zip','w',zipfile.ZIP_DEFLATED) as z:
 for suffix in roots:
  root=home/suffix;names=set()
  for name in ['.installed-by-grey-matter.json','.installed-by-tkt.json']:
   p=root/name;d=json.loads(p.read_text());names.update(d['installed']);z.write(p,p.relative_to(home).as_posix());manifest.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  for p in root.iterdir():
   if p.name.startswith('.installed-'):continue
   rows=list(files(p)) if p.is_dir() else list(files(root))
   if p.name not in names:unowned.extend(rows);continue
   owned_paths.append(str(p))
   for row in rows:
    manifest.append(row)
    if 'sha256' in row:
     f=pathlib.Path(row['path']);z.write(f,f.relative_to(home).as_posix())
record={'schema':1,'managedEntries':owned_paths,'managedFiles':manifest,'unownedBefore':unowned,'archive':str(out/'managed-skills-before.zip'),'archiveSha256':hashlib.sha256((out/'managed-skills-before.zip').read_bytes()).hexdigest()}
(out/'backup-manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':'pass','entriesBackedUp':len(owned_paths),'managedFiles':len(manifest),'unownedFilesHashed':len(unowned),'backupSha256':record['archiveSha256']}))
