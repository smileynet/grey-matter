$ErrorActionPreference = 'Stop'
$env:PATH = 'C:\Users\uosmi\AppData\Local\mise\installs\node\22.23.1;C:\Users\uosmi\AppData\Local\Microsoft\WinGet\Packages\jdx.mise_Microsoft.Winget.Source_8wekyb3d8bbwe\mise\bin;D:\dev-tools\cargo\bin;' + $env:PATH
$env:CARGO_HOME = 'D:\dev-tools\cargo'
$env:RUSTUP_HOME = 'D:\dev-tools\rustup'
& C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node.exe D:/code/tkt-windows-candidate-2b6ff17/tools/release-product.mjs --repo D:/code/tkt-windows-candidate-2b6ff17 --sha 2b6ff173993c9fe413c40287fb1cb3f0a9879ca1 --out D:/code/sharktank-final-tkt-product --execute
exit $LASTEXITCODE
