import pathlib,subprocess,json,hashlib,zipfile
base=pathlib.Path('D:/code/sharktank-cleanup-20261024');node='C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node.exe'
r=subprocess.run(['powershell','-NoProfile','-File','D:/code/sharktank-audit.ps1'],capture_output=True,text=True);audit=json.loads(r.stdout);assert not any(' twice:' in f for f in audit['findings']);assert not audit['errors'];assert all('unowned:' in f for f in audit['findings']);(base/'audit-after.json').write_text(json.dumps(audit,indent=2)+'\n')
r=subprocess.run([node,'D:/code/sharktank-inventory.mjs'],capture_output=True,text=True);assert r.returncode==0;pathlib.Path('D:/code/sharktank-inventory-before.json').rename(base/'inventory-after.json')
record=json.loads((base/'backup-manifest.json').read_text());kept=[]
for row in record['unownedBefore']:
 if '/.codex/skills/.system/' in row['path'].replace(chr(92),'/').lower():continue
 p=pathlib.Path(row['path']);ok=str(p.resolve())==row['link'] if 'link' in row else p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];assert ok,row['path'];kept.append(row)
rows=[]
for suffix in ['.kiro/skills','.codex/skills','.claude/skills','.agents/skills']:
 p=pathlib.Path('C:/Users/uosmi')/suffix;names=[]
 for pack in ['grey-matter','tkt']:
  m=p/('.installed-by-'+pack+'.json')
  if m.exists():names+=json.loads(m.read_text())['installed']
 rows.append({'root':str(p),'managedCount':len(names),'names':sorted(names)});assert len(names)==(0 if '.agents' in suffix else 50)
result={'schema':1,'status':'pass','duplicateFindings':[],'retainedUnownedFindings':audit['findings'],'unownedFilesPreserved':len(kept),'vendorCacheChanges':'Codex client refreshed .system cache; separate from preserved user skills','rootRows':rows,'publicationPerformed':False};(base/'cleanup-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'pass','managedCounts':[r['managedCount'] for r in rows],'unownedFilesPreserved':len(kept),'duplicateFindings':[]}))
