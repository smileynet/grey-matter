import pathlib,json,zipfile,hashlib
home=pathlib.Path('C:/Users/uosmi');root=home/'.gemini/config/plugins';out=pathlib.Path('D:/code/sharktank-cleanup-20261024');rows=[]
with zipfile.ZipFile(out/'agy-plugins-before.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['grey-matter','tkt']:
  p=root/name
  if not p.exists():rows.append({'name':name,'state':'absent'});continue
  m=json.loads((p/'plugin.json').read_text());assert m['name']==name
  files=[]
  for f in p.rglob('*'):
   assert not f.is_symlink() and not f.is_junction()
   if f.is_file():z.write(f,f.relative_to(root).as_posix());files.append({'path':f.relative_to(p).as_posix(),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
  rows.append({'name':name,'manifest':m,'files':files})
(out/'agy-before-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{'name':r['name'],'files':len(r.get('files',[])),'state':r.get('state','backed-up')} for r in rows]))
