import hashlib
import http.client
import json
import sys
import pathlib
import shutil
import socket
import subprocess
import tempfile
import time
import uuid

root = pathlib.Path(tempfile.mkdtemp(prefix='crush-candidate-catalog-'))
home = root / 'home'
project = home / 'project'
project.mkdir(parents=True)
env = {'PATH': '/home/sam/code/grey-matter/.scratch/linux-validation-20261024/tools/bin:/home/sam/.local/share/mise/installs/node/22.23.4/bin:/home/sam/.local/bin:/usr/bin:/bin', 'HOME': str(home)}
for key, child in [('XDG_CONFIG_HOME', 'config'), ('XDG_DATA_HOME', 'data'), ('XDG_STATE_HOME', 'state'), ('XDG_CACHE_HOME', 'cache'), ('CRUSH_GLOBAL_CONFIG', 'global-config'), ('CRUSH_GLOBAL_DATA', 'global-data'), ('CRUSH_SKILLS_DIR', 'user-skills'), ('CRUSH_SOCKET', 'unused.sock')]:
    env[key] = str(root / child)
profile = '(version 1)(allow default)(deny network*)(allow network-outbound (remote ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))'
expected = ['foreign']
report = {'schema': 1, 'kind': 'crush-native-candidate-catalog', 'status': 'fail', 'checks': [], 'environment': env}
process = None
log = None
report["executionPlatform"]="linux-x64"
report["isolation"]={'homes': 'disposable', 'credentials': 'environment allowlist; no user configuration', 'network': 'not-enforced', 'networkIsolationAttempt': {'command': ['bwrap', '--unshare-net', '--ro-bind', '/', '/', '--proc', '/proc', '--dev', '/dev', '--', '/usr/sbin/ip', '-br', 'link', 'show', 'lo'], 'exit': 1, 'stderr': 'bwrap: loopback: Failed RTM_NEWADDR: Operation not permitted'}}
try:
    specs = [('/home/sam/code/grey-matter/.scratch/linux-validation-20261024/grey-worktree', 'scripts/deploy.mjs', '/home/sam/code/grey-matter/.scratch/linux-validation-20261024/grey-artifacts/release-metadata.json'), ('/home/sam/code/grey-matter/.scratch/linux-validation-20261024/tkt-worktree', 'tools/deploy.mjs', '/home/sam/code/grey-matter/.scratch/linux-validation-20261024/tkt-artifacts/release-metadata.json')]
    report['candidates'] = []
    for repo, engine, metadata_path in specs:
        metadata = json.loads(pathlib.Path(metadata_path).read_text())
        asset = next(a for a in metadata['assets'] if a['host'] == 'agy')
        expected += [pathlib.PurePosixPath(f).parent.name for f in asset['files'] if f.endswith('/SKILL.md')]
        command = ['/home/sam/.local/share/mise/installs/node/22.23.4/bin/node', str(pathlib.Path(repo) / engine), '--project', '--no-agy']
        result = subprocess.run(command, cwd=project, env=env, capture_output=True, text=True, timeout=30, check=True)
        report['checks'].append({'command': command, 'exit': result.returncode, 'stdout': result.stdout})
        report['candidates'].append({'product': metadata['name'], 'candidateSha': metadata['candidateSha']})
    foreign = project / '.agents/skills/foreign/SKILL.md'
    foreign.parent.mkdir()
    foreign.write_text('---\nname: foreign\ndescription: Isolated user sentinel.\n---\nForeign sentinel\n')
    reservation = socket.socket()
    reservation.bind(('127.0.0.1', 0))
    port = reservation.getsockname()[1]
    reservation.close()
    command = ['/home/sam/code/grey-matter/.scratch/linux-validation-20261024/tools/bin/crush', 'server', '--host', f'tcp://127.0.0.1:{port}', '--data-dir', str(root / 'server-data')]
    log = (root / 'server.log').open('w')
    process = subprocess.Popen(command, cwd=project, env=env, stdout=log, stderr=log)
    for _ in range(200):
        if process.poll() is not None:
            raise RuntimeError('server stopped before discovery')
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=.1):
                break
        except OSError:
            time.sleep(.05)
    def request(method, path, body=None):
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=10)
        connection.request(method, path, body=json.dumps(body) if body is not None else None, headers={'Content-Type': 'application/json'})
        response = connection.getresponse()
        data = json.loads(response.read())
        connection.close()
        if response.status != 200:
            raise RuntimeError(f'{method} {path}: HTTP {response.status}: {data}')
        report['checks'].append({'method': method, 'path': path, 'status': response.status})
        return data
    workspace = request('POST', '/v1/workspaces', {'path': str(project), 'data_dir': str(root / 'workspace-data'), 'client_id': str(uuid.uuid4())})
    catalog = request('GET', '/v1/workspaces/' + workspace['id'] + '/skills')
    loaded = [s for s in catalog if s['source'] == 'project']
    assert sorted(s['name'] for s in loaded) == sorted(expected)
    assert len(set(s['name'] for s in loaded)) == 51
    assert all(str(project) in s['id'] for s in loaded)
    assert workspace['config'].get('providers', {}) == {}
    assert 'Foreign sentinel' in foreign.read_text()
    report.update(status='pass', catalog=loaded, modelRequests=0, credentialInputs=0, foreignPreserved=True, version=subprocess.run(['/home/sam/code/grey-matter/.scratch/linux-validation-20261024/tools/bin/crush', '--version'], env=env, capture_output=True, text=True, check=True).stdout.strip())
except Exception as error:
    report['errors'] = [repr(error)]
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    if log is not None:
        log.close()
        report['serverLog'] = (root / 'server.log').read_text()
    report['probeSha256'] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
    pathlib.Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + '\n')
    shutil.rmtree(root)
print(json.dumps({'status': report['status'], 'skills': len(report.get('catalog', [])), 'errors': report.get('errors')}))
raise SystemExit(0 if report['status'] == 'pass' else 1)
