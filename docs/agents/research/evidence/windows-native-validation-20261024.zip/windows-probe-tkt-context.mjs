import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join,resolve} from 'node:path';import {execFileSync} from 'node:child_process';
import {isolatedEnvironment} from 'file:///D:/code/grey-windows-candidate-e071b7b/scripts/release-native.mjs';
const c=JSON.parse(readFileSync('D:/code/windows-tkt-candidate-capabilities.json')),root=mkdtempSync(join(tmpdir(),'tkt-context-proof-')),home=join(root,'home');mkdirSync(home);mkdirSync(join(root,'.tickets'));
const env={...isolatedEnvironment(home),DO_NOT_TRACK:'1',TKT_NO_USER_CONFIG:'1'},checks=[];
execFileSync('git',['init',root],{env,encoding:'utf8',stdio:'pipe'});
function run(args,override){const stdout=execFileSync(c.binary,args,{env:override?{...env,TKT_CONTEXT:override}:env,cwd:root,encoding:'utf8'});checks.push({command:['tkt',...args],contextOverride:override,exit:0,stdout});return stdout;}
try {
 for(const[id,tag]of[['01','ink'],['02','platform'],['03',null]])writeFileSync(join(root,'.tickets',id+'-fixture.md'),`---\nid: "${id}"\ntitle: "Fixture ${id}"\nstatus: open\nblocked_by: []\n${tag?'tags: ["'+tag+'"]\n':''}---\n# Fixture\n`);
 run(['context','platform']);const prior=readFileSync(join(root,'.tickets/.context'),'utf8');
 const skill=readFileSync('D:/code/tkt-windows-candidate-2b6ff17/skills/tkt-reconcile/SKILL.md','utf8'),block=skill.match(/```bash\n([\s\S]*?)```/)[1];
 for(const line of block.trim().split('\n')){const command=line.split('#')[0].trim().replace('<stream>','ink');if(command)run(command.split(/\s+/).slice(1));}
 const originalRows=run(['query']).trim().split('\n').map(l=>JSON.parse(l));assert.deepEqual(originalRows.map(x=>x.id),['02','03']);
 const rows=run(['query'],'ink').trim().split('\n').map(l=>JSON.parse(l));assert.deepEqual(rows.map(x=>x.id),['01','03']);assert.ok(rows.every(x=>!('tags'in x)));assert.equal(readFileSync(join(root,'.tickets/.context'),'utf8'),prior);
 assert.deepEqual(run(['query'],'platform').trim().split('\n').map(l=>JSON.parse(l).id),['02','03']);assert.deepEqual(run(['query']).trim().split('\n').map(l=>JSON.parse(l).id),['02','03']);assert.equal(readFileSync(join(root,'.tickets/.context'),'utf8'),prior);
 const report={schema:1,status:'pass',version:c.version,checks,scopedIds:['01','03'],restoredIds:['02','03'],untaggedIncluded:true,originalContextRestored:true};writeFileSync(resolve(process.argv[2]),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:'pass',version:c.version,scopedIds:report.scopedIds,restoredIds:report.restoredIds,untaggedIncluded:true}));
}finally{rmSync(root,{recursive:true,force:true});}
