$ErrorActionPreference='Stop'
$owned=Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -like 'D:\code\windows-pinned-tools\*' }
$rows=@($owned | Select-Object ProcessId,Name,ExecutablePath)
foreach ($p in $owned) {Stop-Process -Id $p.ProcessId -ErrorAction Stop}
$rows | ConvertTo-Json -Depth 4 | Set-Content D:/code/windows-stopped-owned-test-processes.json
foreach ($leaf in @('release-native-FmTOzr','release-native-WxSnzs','release-codex-upgrade-GL0EIS')) {
  $path=Join-Path C:/Users/uosmi/AppData/Local/Temp $leaf
  try {Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; Write-Output "removed $path"}
  catch [System.Management.Automation.ItemNotFoundException] {Write-Output "already absent $path"}
}
