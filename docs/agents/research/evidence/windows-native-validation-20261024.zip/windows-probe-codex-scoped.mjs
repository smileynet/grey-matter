import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,rmSync,readdirSync,realpathSync,renameSync,symlinkSync,lstatSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join,basename,dirname,resolve} from 'node:path';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {catalog as rawCatalog,isolatedEnvironment} from './release-native-catalog-adapter.mjs';import {extractArtifact,verifyArtifacts} from 'file:///D:/code/grey-windows-candidate-e071b7b/scripts/release-artifacts.mjs';
const specs=[['grey-matter','D:/code/grey-matter','v0.1.0','D:/code/windows-grey-artifacts','scripts/deploy.mjs'],['tkt','D:/code/tkt','v0.4.0','D:/code/windows-tkt-artifacts','tools/deploy.mjs']];
const root=mkdtempSync(join(tmpdir(),'release-codex-upgrade-')),home=join(root,'home'),workspace=join(home,'workspace');mkdirSync(workspace,{recursive:true});mkdirSync(join(home,'.codex'));
const env=isolatedEnvironment(home),checks=[],report={schema:1,status:'fail',kind:'previous-release-to-codex',checks,phases:[],scope:'Actual previous tagged bare installers migrated to current sealed Codex plugins; no historical plugin format is asserted.'};
env.PATH='C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1;D:/code/windows-pinned-tools/codex/bin;'+env.PATH;
async function catalog(...args) {
 const response=await rawCatalog(...args),prefix=realpathSync(home).toLowerCase()+'\\';
 report.externalCatalogScope='Windows Known Folder user roots remain outside the disposable home. Only owned fixture assertions run; full Windows catalog isolation remains blocked.';
 for(const group of response.data){const external=group.skills.filter(s=>s.scope!=='system'&&!realpathSync(s.path).toLowerCase().startsWith(prefix));report.externalSkills=external.map(({name,path})=>({name,path}));group.skills=group.skills.filter(s=>s.scope==='system'||realpathSync(s.path).toLowerCase().startsWith(prefix));}
 return response;
}
const profile='(version 1)(allow default)(deny network*)(allow network-outbound (remote ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))';
const run=(binary,args,cwd=workspace)=>{const stdout=execFileSync(binary,args,{env,cwd,encoding:'utf8',timeout:45000,maxBuffer:8*1024*1024});checks.push({command:[binary,...args],cwd,exit:0,stdout});return stdout;};
report.executionPlatform='win32-x64';report.isolation={homes:'disposable',credentials:'environment allowlist; no user configuration',network:'not-enforced'};
try {
 const paths=[];for(const [name,repo,tag,artifacts,engine]of specs){const old=join(root,'old-'+name);mkdirSync(old);run('git',['archive','--format=tar','--output',join(root,name+'.tar'),tag],repo);run('C:/Windows/System32/tar.exe',['-xf',join(root,name+'.tar'),'-C',old]);
  const metadata=verifyArtifacts(artifacts),asset=metadata.assets.find(a=>a.host==='codex'),pack=join(root,name);extractArtifact(join(artifacts,asset.name),pack,asset.files);paths.push({name,old,pack,engine,metadata,asset});
 }
 const grey=paths[0],tkt=paths[1],bare=join(home,'.codex/skills'),shared=join(home,'.agents/skills');
 run(process.execPath,[join(grey.old,'scripts/install-skills.mjs'),'--root',bare,'--root',shared]);run('C:/Program Files/Git/bin/bash.exe',[join(tkt.old,'tools/deploy-skills.sh')]);
 mkdirSync(join(bare,'foreign'));writeFileSync(join(bare,'foreign/SKILL.md'),'---\nname: foreign\ndescription: Preserved user fixture\n---\nForeign sentinel\n');
 const oldNames=readdirSync(bare).filter(n=>!n.startsWith('.'));assert.ok(oldNames.includes('tkt'));report.phases.push({phase:'previous-release-installed',bareNames:oldNames});
 for(const p of paths){const market=JSON.parse(readFileSync(join(p.pack,'.agents/plugins/marketplace.json'))).name;run('D:/code/windows-pinned-tools/codex/bin/codex.exe',['plugin','marketplace','add',p.pack,'--json']);run('D:/code/windows-pinned-tools/codex/bin/codex.exe',['plugin','add',`${p.name}@${market}`,'--json']);}
 try {run(process.execPath,['D:/code/tkt-windows-candidate-2b6ff17/tools/migrate-legacy-skills.mjs','--source',join(tkt.old,'skills/tkt'),'--home',home,'--execute']);}
 catch(error) {
  const migration=JSON.parse(error.stdout);assert.equal(migration.status,'fail');assert.equal(migration.removed,0);
  const source=join(tkt.old,'skills/tkt'),entries=readdirSync(source,{recursive:true}).sort();
  const files=readdirSync(source,{recursive:true,withFileTypes:true}).filter(e=>e.isFile()).map(e=>join(e.parentPath,e.name).slice(source.length+1));
  const reviewed=[];
  for(const row of migration.rows.filter(r=>r.action==='preserve')) {
   assert.equal(row.reason,'not a legacy symlink; review manually');assert.ok(row.path.startsWith(home+'\\'));
   assert.deepEqual(readdirSync(row.path,{recursive:true}).sort(),entries);
   for(const file of files)assert.deepEqual(readFileSync(join(row.path,file)),readFileSync(join(source,file)));
   reviewed.push({path:row.path,filesMatched:files.length,action:'remove-owned-byte-identical-legacy-copy'});rmSync(row.path,{recursive:true});
  }
  report.windowsLegacyMigration={automatic:migration,manualFixtureReview:reviewed,scope:'Git Bash created copies instead of symlinks. Migration correctly preserved them; explicit byte-for-byte review removed only owned fixtures.'};
 }

 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const response=await catalog('D:/code/windows-pinned-tools/codex/bin/codex.exe',env,workspace),groups=response.data,errors=groups.flatMap(g=>g.errors);assert.deepEqual(errors,[]);
 const allSkills=groups.flatMap(g=>g.skills),system=allSkills.filter(s=>s.scope==='system');report.systemSkills=system.map(({name,path,scope})=>({name,path,scope}));const skills=allSkills.filter(s=>!system.includes(s)),expected=['foreign',...paths.flatMap(p=>Object.keys(p.asset.files).filter(f=>f.endsWith('/SKILL.md')).map(f=>`${p.name}:${basename(dirname(f))}`))].sort();
 assert.deepEqual(skills.map(s=>s.name).sort(),expected);assert.equal(new Set(skills.map(s=>s.name)).size,51);
 assert.deepEqual(readdirSync(bare).filter(n=>!n.startsWith('.')),['foreign']);assert.deepEqual(readdirSync(shared).filter(n=>!n.startsWith('.')),[]);assert.match(readFileSync(join(bare,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);
 const first=skills.map(({name,path})=>({name,path}));
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const repeated=(await catalog('D:/code/windows-pinned-tools/codex/bin/codex.exe',env,workspace)).data.flatMap(g=>g.skills).filter(s=>s.scope!=='system').map(({name,path})=>({name,path}));assert.deepEqual(repeated,first);
 for(const p of paths){const cache=join(home,'.codex/plugins/cache',p.name,p.name,p.metadata.version),file=Object.keys(p.asset.files).find(f=>f.endsWith('/SKILL.md'));writeFileSync(join(cache,file),readFileSync(join(cache,file),'utf8')+'\nStale cache control\n');run(process.execPath,[join(p.pack,p.engine),'--no-agy']);for(const [entry,value]of Object.entries(p.asset.files))assert.equal(createHash('sha256').update(readFileSync(join(cache,entry))).digest('hex'),value.sha256);}
 report.sameVersionCacheRepair=true;
 const configFile=join(home,'.codex/config.toml'),enabled=readFileSync(configFile,'utf8');assert.equal((enabled.match(/enabled = true/g)||[]).length,2);writeFileSync(configFile,enabled.replaceAll('enabled = true','enabled = false'));
 const nonSystem=r=>r.data.flatMap(g=>g.skills).filter(s=>s.scope!=='system');
 assert.deepEqual(nonSystem(await catalog('D:/code/windows-pinned-tools/codex/bin/codex.exe',env,workspace)).map(s=>s.name),['foreign']);
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const disabledBare=nonSystem(await catalog('D:/code/windows-pinned-tools/codex/bin/codex.exe',env,workspace));const bareExpected=['foreign',...paths.flatMap(p=>Object.keys(p.asset.files).filter(f=>f.endsWith('/SKILL.md')).map(f=>basename(dirname(f))))].sort();assert.deepEqual(disabledBare.map(s=>s.name).sort(),bareExpected);report.disabledBareCatalog=disabledBare.map(({name,path})=>({name,path}));
 mkdirSync(join(home,'.kiro'));const kiro=join(home,'.kiro/skills');renameSync(bare,kiro);symlinkSync(kiro,bare,'junction');writeFileSync(configFile,enabled);
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 assert.equal(lstatSync(bare).isSymbolicLink(),false);assert.deepEqual(readdirSync(bare).filter(n=>!n.startsWith('.')),['foreign']);assert.deepEqual(readdirSync(kiro).filter(n=>!n.startsWith('.')).sort(),bareExpected);assert.match(readFileSync(join(kiro,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);assert.match(readFileSync(join(bare,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);
 const afterSeparation=nonSystem(await catalog('D:/code/windows-pinned-tools/codex/bin/codex.exe',env,workspace));assert.deepEqual(afterSeparation.map(s=>s.name).sort(),expected);report.reEnabledAfterSymlinkCatalog=afterSeparation.map(({name,path})=>({name,path}));report.symlinkSeparated=true;report.foreignPreservedInBothRoots=true;
 report.status='partial';report.fixtureControls='pass';report.nativeVersion=run('D:/code/windows-pinned-tools/codex/bin/codex.exe',['--version']).trim();report.catalog=first;report.repeatedCatalogIdentical=true;report.foreignPreserved=true;report.removedBareNames=oldNames.filter(n=>n!=='foreign');report.candidates=paths.map(p=>({product:p.name,previousTag:specs.find(s=>s[0]===p.name)[2],candidateSha:p.metadata.candidateSha,asset:p.asset.name,assetSha256:p.asset.sha256}));
}catch(error){report.errors=[error.stack];report.failureOutput={stdout:error.stdout?.toString(),stderr:error.stderr?.toString()};process.exitCode=1;}
finally{report.probeSha256=createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex');report.catalogAdapterSha256=createHash('sha256').update(readFileSync(new URL('./release-native-catalog-adapter.mjs',import.meta.url))).digest('hex');writeFileSync(resolve(process.argv[2]),JSON.stringify(report,null,2)+'\n');try{rmSync(root,{recursive:true,force:true,maxRetries:20,retryDelay:100});report.cleanup='pass';}catch(error){report.cleanup=error.message;report.retainedFixtureRoot=root;}writeFileSync(resolve(process.argv[2]),JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({status:report.status,catalogCount:report.catalog?.length,errors:report.errors}));
