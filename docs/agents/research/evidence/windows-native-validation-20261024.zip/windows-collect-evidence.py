import hashlib,json,pathlib,platform,subprocess,zipfile
base=pathlib.Path('D:/code')
paths=[]
for folder in ['grey-windows-evidence-e071b7b','grey-windows-evidence-e071b7b-rerun','tkt-windows-product-2b6ff17','windows-grey-native','windows-tkt-native','windows-grey-native-updater-control','windows-grey-native-pinned','windows-tkt-native-pinned']:
 paths.extend((base/folder).glob('*'))
for name in ['windows-bare-evidence.json','windows-kiro-evidence.json','windows-kiro-pinned-evidence.json','windows-kiro-env-evidence.json','windows-kiro-isolated-evidence.json','windows-crush-evidence.json','windows-codex-upgrade.json','windows-codex-upgrade-reviewed.json','windows-codex-scoped-evidence.json','windows-claude-upgrade.json','windows-claude-upgrade-reviewed.json','windows-agy-upgrade.json','windows-tkt-surface.json','windows-tkt-context.json','windows-tkt-candidate-capabilities.json']:
 paths.append(base/name)
for pattern in ['windows-*.ps1','windows-*.mjs','windows-*.py','release-native-catalog-adapter.mjs']:
 paths.extend(base.glob(pattern))
paths.extend([base/'windows-pinned-tools/downloads.json',base/'windows-pinned-tools/kiro-extract.log'])
tools=[base/'windows-pinned-tools/codex/bin/codex.exe',base/'windows-pinned-tools/claude.exe',base/'windows-pinned-tools/agy/antigravity.exe',base/'windows-pinned-tools/agy-probe.exe',base/'windows-pinned-tools/opencode/opencode.exe',base/'windows-pinned-tools/crush/crush_0.98.1_Windows_x86_64/crush.exe',base/'windows-pinned-tools/kiro-extracted/LocalApp/Kiro-Cli/kiro-cli.exe',base/'windows-validation-tools/tkt.exe']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'schema':1,'platform':platform.platform(),'machine':platform.machine(),'tools':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in tools], 'git':[],'experiments':{'initialNative':'Both helpers wrote passing package rows but exited 1 on AGY update.lock cleanup. These are not passing terminal runs. The private AGY payload later reported 1.4.7. Original verified 1.4.6 ZIP restored; final canonical helper runs use the retained updater-disabling native launcher.','kiro':'Initial home-only redirects exposed existing user skill metadata. The supported KIRO_HOME override then produced exactly the 51 fixture skills. Initial metadata probes may have created native session records; personal state was not deleted or edited to make checks pass.','codex':'Known Folder user root cannot be overridden by the supplied HOME/USERPROFILE/CODEX_HOME. Scoped assertions cannot close full-isolation criterion.'}}
for repo in ['grey-matter','tkt','grey-windows-candidate-e071b7b','tkt-windows-candidate-2b6ff17']:
 row={'repo':str(base/repo)}
 for key,args in [('head',['rev-parse','HEAD']),('status',['status','--porcelain=v1'])]:
  r=subprocess.run(['git','-C',str(base/repo),*args],capture_output=True,text=True);row[key]={'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 record['git'].append(row)
(base/'windows-machine-record.json').write_text(json.dumps(record,indent=2)+'\n')
paths.append(base/'windows-machine-record.json')
paths.append(base/'windows-stopped-owned-test-processes.json')
paths.append(base/'windows-tkt-hooks.json')
paths=sorted(set(p for p in paths if p.is_file()))
manifest=[{'path':p.relative_to(base).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in paths]
(base/'windows-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(base/'windows-validation-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(base).as_posix())
 z.write(base/'windows-evidence-manifest.json','windows-evidence-manifest.json')
print(json.dumps({'files':len(paths)+1,'zipSha256':sha(base/'windows-validation-evidence.zip'),'bytes':(base/'windows-validation-evidence.zip').stat().st_size}))
