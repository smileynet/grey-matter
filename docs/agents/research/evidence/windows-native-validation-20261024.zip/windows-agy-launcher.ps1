$ErrorActionPreference='Stop'
$source=@'
using System;
using System.Diagnostics;
public class PinnedAgyProbe {
  public static int Main(string[] args) {
    var start = new ProcessStartInfo("D:/code/windows-pinned-tools/agy/antigravity.exe", String.Join(" ", Array.ConvertAll(args, a => "\"" + a + "\"")));
    start.UseShellExecute = false;
    start.EnvironmentVariables["AGY_CLI_DISABLE_AUTO_UPDATE"] = "true";
    using (var child = Process.Start(start)) { child.WaitForExit(); return child.ExitCode; }
  }
}
'@
Add-Type -TypeDefinition $source -OutputAssembly D:/code/windows-pinned-tools/agy-probe.exe -OutputType ConsoleApplication
& D:/code/windows-pinned-tools/agy-probe.exe --version
