$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
New-Item -ItemType Directory -Force D:/code/windows-pinned-tools | Out-Null
$records=@()
Write-Output 'Downloading codex'
# Existing download retained; hash rechecked below
$hash=(Get-FileHash 'D:/code/windows-pinned-tools/codex.tar.gz' -Algorithm SHA256).Hash.ToLower()
if ($hash -ne 'c156c8feb8cb20197bf74d2c6daffed1fec0a8c21a03bc2ca90d7ff81927b0c5') { throw 'codex checksum mismatch' }
$records+=@{name='codex';url='https://github.com/openai/codex/releases/download/rust-v0.147.0/codex-package-x86_64-pc-windows-msvc.tar.gz';sha256=$hash;path='D:/code/windows-pinned-tools/codex.tar.gz'}
New-Item -ItemType Directory -Force 'D:/code/windows-pinned-tools/codex' | Out-Null
& C:/Windows/System32/tar.exe -xzf 'D:/code/windows-pinned-tools/codex.tar.gz' -C 'D:/code/windows-pinned-tools/codex'
if ($LASTEXITCODE -ne 0) {throw 'tar failed'}
Write-Output 'Downloading claude'
Invoke-WebRequest -UseBasicParsing 'https://downloads.claude.ai/claude-code-releases/2.1.310/win32-x64/claude.exe' -OutFile 'D:/code/windows-pinned-tools/claude.exe'
$hash=(Get-FileHash 'D:/code/windows-pinned-tools/claude.exe' -Algorithm SHA256).Hash.ToLower()
if ($hash -ne 'f9a3920634ae3b961ee92c2eb58d0051f5f8852b120983d0a4f57b6a5efeba61') { throw 'claude checksum mismatch' }
$records+=@{name='claude';url='https://downloads.claude.ai/claude-code-releases/2.1.310/win32-x64/claude.exe';sha256=$hash;path='D:/code/windows-pinned-tools/claude.exe'}
Write-Output 'Downloading agy'
Invoke-WebRequest -UseBasicParsing 'https://github.com/google-antigravity/antigravity-cli/releases/download/1.4.6/agy_cli_windows_x64.zip' -OutFile 'D:/code/windows-pinned-tools/agy.zip'
$hash=(Get-FileHash 'D:/code/windows-pinned-tools/agy.zip' -Algorithm SHA256).Hash.ToLower()
if ($hash -ne 'e192f8cb448d3f8601c91a877a244d93b31d790c14f986b35f0338f0d003a386') { throw 'agy checksum mismatch' }
$records+=@{name='agy';url='https://github.com/google-antigravity/antigravity-cli/releases/download/1.4.6/agy_cli_windows_x64.zip';sha256=$hash;path='D:/code/windows-pinned-tools/agy.zip'}
Expand-Archive 'D:/code/windows-pinned-tools/agy.zip' 'D:/code/windows-pinned-tools/agy'
Write-Output 'Downloading opencode'
Invoke-WebRequest -UseBasicParsing 'https://github.com/anomalyco/opencode/releases/download/v1.18.21/opencode-windows-x64-baseline.zip' -OutFile 'D:/code/windows-pinned-tools/opencode.zip'
$hash=(Get-FileHash 'D:/code/windows-pinned-tools/opencode.zip' -Algorithm SHA256).Hash.ToLower()
if ($hash -ne 'cffd857166a52c7ae36a337d6b42136910aaa534cf2b9d658c4ce71b903d12b8') { throw 'opencode checksum mismatch' }
$records+=@{name='opencode';url='https://github.com/anomalyco/opencode/releases/download/v1.18.21/opencode-windows-x64-baseline.zip';sha256=$hash;path='D:/code/windows-pinned-tools/opencode.zip'}
Expand-Archive 'D:/code/windows-pinned-tools/opencode.zip' 'D:/code/windows-pinned-tools/opencode'
Write-Output 'Downloading crush'
Invoke-WebRequest -UseBasicParsing 'https://github.com/charmbracelet/crush/releases/download/v0.98.1/crush_0.98.1_Windows_x86_64.zip' -OutFile 'D:/code/windows-pinned-tools/crush.zip'
$hash=(Get-FileHash 'D:/code/windows-pinned-tools/crush.zip' -Algorithm SHA256).Hash.ToLower()
if ($hash -ne 'f0e456c560cc2e69eb2d4565768ae0fe2e04f4da90a0898374c45ab2caa33f2e') { throw 'crush checksum mismatch' }
$records+=@{name='crush';url='https://github.com/charmbracelet/crush/releases/download/v0.98.1/crush_0.98.1_Windows_x86_64.zip';sha256=$hash;path='D:/code/windows-pinned-tools/crush.zip'}
Expand-Archive 'D:/code/windows-pinned-tools/crush.zip' 'D:/code/windows-pinned-tools/crush'
$records | ConvertTo-Json -Depth 6 | Set-Content D:/code/windows-pinned-tools/downloads.json
Get-ChildItem D:/code/windows-pinned-tools -Recurse -Filter *.exe | Select-Object -ExpandProperty FullName
