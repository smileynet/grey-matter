$ErrorActionPreference='Stop'
Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'antigravity.exe' } | Select-Object ProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Depth 4
