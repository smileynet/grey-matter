import assert from 'node:assert/strict';
import {parse as parseYaml} from 'file:///D:/code/grey-windows-candidate-e071b7b/node_modules/yaml/dist/index.js';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,rmSync,readdirSync,cpSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join,basename,dirname,resolve} from 'node:path';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {isolatedEnvironment} from 'file:///D:/code/grey-windows-candidate-e071b7b/scripts/release-native.mjs';import {extractArtifact,verifyArtifacts} from 'file:///D:/code/grey-windows-candidate-e071b7b/scripts/release-artifacts.mjs';
const specs=[['grey-matter','D:/code/grey-matter','v0.1.0','D:/code/windows-grey-artifacts','scripts/deploy.mjs'],['tkt','D:/code/tkt','v0.4.0','D:/code/windows-tkt-artifacts','tools/deploy.mjs']];
const root=mkdtempSync(join(tmpdir(),'release-claude-upgrade-')),home=join(root,'home'),workspace=join(home,'workspace');mkdirSync(workspace,{recursive:true});mkdirSync(join(home,'.claude'));
const env={...isolatedEnvironment(home),npm_config_cache:join(home,'.npm-cache'),npm_config_offline:'true',npm_config_userconfig:join(home,'empty-npmrc'),npm_config_globalconfig:join(home,'empty-global-npmrc')},checks=[],report={schema:1,status:'fail',kind:'previous-release-to-claude',checks,phases:[],scope:'Actual previous tagged bare installers migrated to current sealed Claude plugins; no historical plugin format is asserted.'};
env.PATH='C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1;D:/code/windows-pinned-tools/codex/bin;'+env.PATH;
const profile='(version 1)(allow default)(deny network*)(allow network-outbound (remote ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))';
const run=(binary,args,cwd=workspace)=>{if(binary==='claude'){binary='D:/code/windows-pinned-tools/claude.exe';args=['--debug-file',join(home,'debug-'+checks.length+'.log'),...args];}const stdout=execFileSync(binary,args,{env,cwd,encoding:'utf8',timeout:45000,maxBuffer:8*1024*1024});checks.push({command:[binary,...args],cwd,exit:0,stdout});return stdout;};
report.executionPlatform='win32-x64';report.isolation={homes:'disposable',credentials:'environment allowlist; no user configuration',network:'not-enforced'};
try {
 const paths=[];for(const [name,repo,tag,artifacts,engine]of specs){const old=join(root,'old-'+name);mkdirSync(old);run('git',['archive','--format=tar','--output',join(root,name+'.tar'),tag],repo);run('C:/Windows/System32/tar.exe',['-xf',join(root,name+'.tar'),'-C',old]);
  const metadata=verifyArtifacts(artifacts),asset=metadata.assets.find(a=>a.host==='claude'),pack=join(root,name);assert.equal(asset.host,'claude');extractArtifact(join(artifacts,asset.name),pack,asset.files);paths.push({name,old,pack,engine,metadata,asset});
 }
 const warm=join(root,'npm-warm');mkdirSync(warm);for(const name of ['package.json','package-lock.json'])cpSync(join(paths[1].pack,name),join(warm,name));writeFileSync(env.npm_config_userconfig,'');writeFileSync(env.npm_config_globalconfig,'');
 const bootstrapArgs=['ci','--ignore-scripts','--no-audit','--no-fund'];const bootstrap=execFileSync(process.execPath,['C:/Users/uosmi/AppData/Local/mise/installs/node/22.23.1/node_modules/npm/bin/npm-cli.js',...bootstrapArgs],{env:{...env,npm_config_offline:'false'},cwd:warm,encoding:'utf8',timeout:45000,maxBuffer:8*1024*1024});report.npmBootstrap={command:['npm',...bootstrapArgs],cwd:warm,cache:env.npm_config_cache,lockSha256:createHash('sha256').update(readFileSync(join(warm,'package-lock.json'))).digest('hex'),exit:0,stdout:bootstrap,scope:'Fresh owned cache; public lockfile downloads before network-isolated native install. No user npm config/cache or credentials.'};
 const grey=paths[0],tkt=paths[1],bare=join(home,'.claude/skills'),shared=join(home,'.agents/skills');
 run(process.execPath,[join(grey.old,'scripts/install-skills.mjs'),'--root',bare,'--root',shared]);run('C:/Program Files/Git/bin/bash.exe',[join(tkt.old,'tools/deploy-skills.sh')]);
 mkdirSync(join(bare,'foreign'));writeFileSync(join(bare,'foreign/SKILL.md'),'---\nname: foreign\ndescription: Preserved user fixture\n---\nForeign sentinel\n');
 const oldNames=readdirSync(bare).filter(n=>!n.startsWith('.'));assert.ok(oldNames.includes('tkt'));report.phases.push({phase:'previous-release-installed',bareNames:oldNames});
 for(const p of [...paths].reverse()){const market=JSON.parse(readFileSync(join(p.pack,'.claude-plugin/marketplace.json'))).name;run('claude',['plugin','marketplace','add',p.pack]);run('claude',['plugin','install',`${p.name}@${market}`,'--json']);}
 try {run(process.execPath,['D:/code/tkt-windows-candidate-2b6ff17/tools/migrate-legacy-skills.mjs','--source',join(tkt.old,'skills/tkt'),'--home',home,'--execute']);}
 catch(error) {
  const migration=JSON.parse(error.stdout);assert.equal(migration.status,'fail');assert.equal(migration.removed,0);
  const source=join(tkt.old,'skills/tkt'),entries=readdirSync(source,{recursive:true}).sort();
  const files=readdirSync(source,{recursive:true,withFileTypes:true}).filter(e=>e.isFile()).map(e=>join(e.parentPath,e.name).slice(source.length+1));
  const reviewed=[];
  for(const row of migration.rows.filter(r=>r.action==='preserve')) {
   assert.equal(row.reason,'not a legacy symlink; review manually');assert.ok(row.path.startsWith(home+'\\'));
   assert.deepEqual(readdirSync(row.path,{recursive:true}).sort(),entries);
   for(const file of files)assert.deepEqual(readFileSync(join(row.path,file)),readFileSync(join(source,file)));
   reviewed.push({path:row.path,filesMatched:files.length,action:'remove-owned-byte-identical-legacy-copy'});rmSync(row.path,{recursive:true});
  }
  report.windowsLegacyMigration={automatic:migration,manualFixtureReview:reviewed,scope:'Git Bash created copies instead of symlinks. Migration correctly preserved them; explicit byte-for-byte review removed only owned fixtures.'};
 }

 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const sessionCatalog=()=>{
  const args=['-p','--input-format','stream-json','--output-format','stream-json','--verbose','--setting-sources','user'];
  const request={type:'control_request',request_id:'release-catalog',request:{subtype:'initialize'}};
  const stdout=execFileSync('D:/code/windows-pinned-tools/claude.exe',args,{env,cwd:workspace,input:JSON.stringify(request)+'\n',encoding:'utf8',timeout:45000,maxBuffer:8*1024*1024});
  const frame=stdout.trim().split('\n').map(line=>JSON.parse(line)).find(frame=>frame.type==='control_response'&&frame.response.request_id===request.request_id);
  assert.equal(frame.response.subtype,'success');
  const commands=frame.response.response.commands;assert.ok(Array.isArray(commands));
  return commands.filter(command=>/^(grey-matter|tkt):/.test(command.name)).map(command=>command.name).sort();
 };
 const expectedCommands=paths.flatMap(p=>Object.keys(p.asset.files).filter(f=>f.endsWith('/SKILL.md')).flatMap(f=>{
  const text=readFileSync(join(p.pack,f),'utf8');const metadata=parseYaml(text.split('---')[1]);
  return metadata['user-invocable']===false?[]:[p.name+':'+(metadata.name||basename(dirname(f)))];
 })).sort();
 report.enabledSessionCommands=sessionCatalog();assert.deepEqual(report.enabledSessionCommands,expectedCommands);
 const list=JSON.parse(run('claude',['plugin','list','--json']));report.inventory=list;
 const catalogs=paths.map(p=>{const details=run('claude',['plugin','details',p.name]);const expected=Object.keys(p.asset.files).filter(f=>f.endsWith('/SKILL.md')).map(f=>basename(dirname(f))).sort();assert.equal(Number(/Skills \((\d+)\)/.exec(details)?.[1]),expected.length);for(const name of expected)assert.ok(details.includes(name),'missing skill '+name);assert.match(details,/Hooks \(1\)/,'Claude bundle must load its hook');return {product:p.name,expected,details};});report.catalogs=catalogs;
 assert.deepEqual(readdirSync(bare).filter(n=>!n.startsWith('.')),['foreign']);assert.deepEqual(readdirSync(shared).filter(n=>!n.startsWith('.')),[]);assert.match(readFileSync(join(bare,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const repeated=paths.map(p=>run('claude',['plugin','details',p.name]));assert.deepEqual(repeated,catalogs.map(c=>c.details));
 let dependencyRefused=false;try{run('claude',['plugin','disable','tkt@tkt']);}catch(error){assert.match(error.stderr.toString(),/still required by grey-matter/);dependencyRefused=true;report.expectedDependencyRefusal={command:['claude','plugin','disable','tkt@tkt'],exit:error.status,reason:'dependency-required',stderrSha256:createHash('sha256').update(error.stderr).digest('hex')};}assert.ok(dependencyRefused);report.dependencyDisableGuard=true;
 for(const p of paths){run('claude',['plugin','disable',p.name+'@'+p.name]);const disabled=JSON.parse(run('claude',['plugin','list','--json']));assert.equal(disabled.find(r=>r.id===p.name+'@'+p.name).enabled,false);}
 report.disabledSessionCommands=sessionCatalog();assert.deepEqual(report.disabledSessionCommands,[]);
 for(const p of [...paths].reverse())run('claude',['plugin','enable',p.name+'@'+p.name]);
 for(const p of paths)assert.equal(JSON.parse(run('claude',['plugin','list','--json'])).find(r=>r.id===p.name+'@'+p.name).enabled,true);
 report.reenabledSessionCommands=sessionCatalog();assert.deepEqual(report.reenabledSessionCommands,expectedCommands);report.sessionCatalogScope='User-invocable command metadata only; initialize control frame, no user prompt or model request; hidden skills excluded by declared policy.';
 report.status='pass';report.nativeVersion=run('claude',['--version']).trim();report.catalogCount=catalogs.reduce((n,c)=>n+c.expected.length,0);report.disableEnablePassed=true;report.repeatedCatalogIdentical=true;report.foreignPreserved=true;report.removedBareNames=oldNames.filter(n=>n!=='foreign');report.candidates=paths.map(p=>({product:p.name,previousTag:specs.find(s=>s[0]===p.name)[2],candidateSha:p.metadata.candidateSha,host:p.asset.host,asset:p.asset.name,assetSha256:p.asset.sha256}));
}catch(error){report.errors=[error.stack];report.failureOutput={stdout:error.stdout?.toString(),stderr:error.stderr?.toString()};process.exitCode=1;}
finally{report.debugLogs=readdirSync(home).filter(n=>n.startsWith('debug-')).map(n=>({name:n,text:readFileSync(join(home,n),'utf8')}));report.probeSha256=createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex');writeFileSync(resolve(process.argv[2]),JSON.stringify(report,null,2)+'\n');rmSync(root,{recursive:true,force:true});}
console.log(JSON.stringify({status:report.status,catalogCount:report.catalogCount,errors:report.errors}));
