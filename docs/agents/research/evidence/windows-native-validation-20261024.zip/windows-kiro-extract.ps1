$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$msi='D:/code/windows-pinned-tools/kiro-2.34.0.msi'
Invoke-WebRequest -UseBasicParsing https://prod.download.cli.kiro.dev/stable/2.34.0/kiro-cli-x86_64-pc-windows-msvc.msi -OutFile $msi
if ((Get-FileHash $msi -Algorithm SHA256).Hash.ToLower() -ne '2a09478e53c8097d168ce87f8b0e111537c21a5c3b0d7ea9bc74e4d60c51c4ca') {throw 'Kiro MSI checksum mismatch'}
$p=Start-Process C:/Windows/System32/msiexec.exe -ArgumentList '/a D:\code\windows-pinned-tools\kiro-2.34.0.msi /qn TARGETDIR=D:\code\windows-pinned-tools\kiro-extracted /l*v D:\code\windows-pinned-tools\kiro-extract.log' -Wait -PassThru
if ($p.ExitCode -ne 0) {throw "MSI administrative extraction exit $($p.ExitCode)"}
Get-ChildItem D:/code/windows-pinned-tools/kiro-extracted -Recurse -Filter *.exe | Select-Object -ExpandProperty FullName
