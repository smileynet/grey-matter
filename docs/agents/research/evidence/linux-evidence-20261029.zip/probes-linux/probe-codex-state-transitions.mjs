import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,rmSync,readdirSync,realpathSync,renameSync,symlinkSync,lstatSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join,basename,dirname,resolve} from 'node:path';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {catalog,isolatedEnvironment} from './release-native-catalog-adapter.mjs';import {extractArtifact,verifyArtifacts} from '/home/sam/release-work/20261028/prepare-2/worktree/scripts/release-artifacts.mjs';
const specs=[['grey-matter','/home/sam/code/grey-matter','v0.1.0','/home/sam/release-work/20261028/prepare-2/artifacts','scripts/deploy.mjs'],['tkt','/home/sam/code/tkt','v0.4.0','/home/sam/release-work/20261028/tkt-prepare/artifacts','tools/deploy.mjs']];
const root=mkdtempSync(join(tmpdir(),'release-codex-upgrade-')),home=join(root,'home'),workspace=join(home,'workspace');mkdirSync(workspace,{recursive:true});mkdirSync(join(home,'.codex'));
const env=isolatedEnvironment(home),checks=[],report={schema:1,status:'fail',kind:'previous-release-to-codex',checks,phases:[],scope:'Actual previous tagged bare installers migrated to current sealed Codex plugins; no historical plugin format is asserted.'};
const profile='(version 1)(allow default)(deny network*)(allow network-outbound (remote ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))';
const run=(binary,args,cwd=workspace)=>{const stdout=execFileSync(binary,args,{env,cwd,encoding:'utf8',timeout:45000,maxBuffer:8*1024*1024});checks.push({command:[binary,...args],cwd,exit:0,stdout});return stdout;};
report.executionPlatform="linux-x64";report.isolation={"homes": "disposable", "credentials": "environment allowlist; no user configuration", "network": "not-enforced", "networkIsolationAttempt": {"command": ["bwrap", "--unshare-net", "--ro-bind", "/", "/", "--proc", "/proc", "--dev", "/dev", "--", "/usr/sbin/ip", "-br", "link", "show", "lo"], "exit": 1, "stderr": "bwrap: loopback: Failed RTM_NEWADDR: Operation not permitted"}};
try {
 const paths=[];for(const [name,repo,tag,artifacts,engine]of specs){const old=join(root,'old-'+name);mkdirSync(old);run('git',['archive','--format=tar','--output',join(root,name+'.tar'),tag],repo);run('tar',['-xf',join(root,name+'.tar'),'-C',old]);
  const metadata=verifyArtifacts(artifacts),asset=metadata.assets.find(a=>a.host==='codex'),pack=join(root,name);extractArtifact(join(artifacts,asset.name),pack,asset.files);paths.push({name,old,pack,engine,metadata,asset});
 }
 const grey=paths[0],tkt=paths[1],bare=join(home,'.codex/skills'),shared=join(home,'.agents/skills');
 run(process.execPath,[join(grey.old,'scripts/install-skills.mjs'),'--root',bare,'--root',shared]);run('/usr/bin/bash',[join(tkt.old,'tools/deploy-skills.sh')]);
 mkdirSync(join(bare,'foreign'));writeFileSync(join(bare,'foreign/SKILL.md'),'---\nname: foreign\ndescription: Preserved user fixture\n---\nForeign sentinel\n');
 const oldNames=readdirSync(bare).filter(n=>!n.startsWith('.'));assert.ok(oldNames.includes('tkt'));report.phases.push({phase:'previous-release-installed',bareNames:oldNames});
 for(const p of paths){const market=JSON.parse(readFileSync(join(p.pack,'.agents/plugins/marketplace.json'))).name;run('codex',['plugin','marketplace','add',p.pack,'--json']);run('codex',['plugin','add',`${p.name}@${market}`,'--json']);}
 run(process.execPath,['/home/sam/release-work/20261028/tkt-prepare/worktree/tools/migrate-legacy-skills.mjs','--source',join(tkt.old,'skills/tkt'),'--execute']);
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const response=await catalog('codex',env,workspace),groups=response.data,errors=groups.flatMap(g=>g.errors);assert.deepEqual(errors,[]);
 const allSkills=groups.flatMap(g=>g.skills),system=allSkills.filter(s=>s.path.startsWith(join(realpathSync(home),'.codex/skills/.system')+'/'));report.systemSkills=system.map(({name,path,scope})=>({name,path,scope}));const skills=allSkills.filter(s=>!system.includes(s)),expected=['foreign',...paths.flatMap(p=>Object.keys(p.asset.files).filter(f=>f.endsWith('/SKILL.md')).map(f=>`${p.name}:${basename(dirname(f))}`))].sort();
 assert.deepEqual(skills.map(s=>s.name).sort(),expected);assert.equal(new Set(skills.map(s=>s.name)).size,53);
 assert.deepEqual(readdirSync(bare).filter(n=>!n.startsWith('.')),['foreign']);assert.deepEqual(readdirSync(shared).filter(n=>!n.startsWith('.')),[]);assert.match(readFileSync(join(bare,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);
 const first=skills.map(({name,path})=>({name,path}));
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const repeated=(await catalog('codex',env,workspace)).data.flatMap(g=>g.skills).filter(s=>!s.path.startsWith(join(realpathSync(home),'.codex/skills/.system')+'/')).map(({name,path})=>({name,path}));assert.deepEqual(repeated,first);
 for(const p of paths){const cache=join(home,'.codex/plugins/cache',p.name,p.name,p.metadata.version),file=Object.keys(p.asset.files).find(f=>f.endsWith('/SKILL.md'));writeFileSync(join(cache,file),readFileSync(join(cache,file),'utf8')+'\nStale cache control\n');run(process.execPath,[join(p.pack,p.engine),'--no-agy']);for(const [entry,value]of Object.entries(p.asset.files))assert.equal(createHash('sha256').update(readFileSync(join(cache,entry))).digest('hex'),value.sha256);}
 report.sameVersionCacheRepair=true;
 const configFile=join(home,'.codex/config.toml'),enabled=readFileSync(configFile,'utf8');assert.equal((enabled.match(/enabled = true/g)||[]).length,2);writeFileSync(configFile,enabled.replaceAll('enabled = true','enabled = false'));
 const nonSystem=r=>r.data.flatMap(g=>g.skills).filter(s=>!(s.scope==='system'&&s.path.startsWith(realpathSync(home)+'/')&&s.path.includes('/skills/.system/')));
 assert.deepEqual(nonSystem(await catalog('codex',env,workspace)).map(s=>s.name),['foreign']);
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 const disabledBare=nonSystem(await catalog('codex',env,workspace));const bareExpected=['foreign',...paths.flatMap(p=>Object.keys(p.asset.files).filter(f=>f.endsWith('/SKILL.md')).map(f=>basename(dirname(f))))].sort();assert.deepEqual(disabledBare.map(s=>s.name).sort(),bareExpected);report.disabledBareCatalog=disabledBare.map(({name,path})=>({name,path}));
 mkdirSync(join(home,'.kiro'));const kiro=join(home,'.kiro/skills');renameSync(bare,kiro);symlinkSync(kiro,bare,'dir');writeFileSync(configFile,enabled);
 for(const p of paths)run(process.execPath,[join(p.pack,p.engine),'--no-agy']);
 assert.equal(lstatSync(bare).isSymbolicLink(),false);assert.deepEqual(readdirSync(bare).filter(n=>!n.startsWith('.')),['foreign']);assert.deepEqual(readdirSync(kiro).filter(n=>!n.startsWith('.')).sort(),bareExpected);assert.match(readFileSync(join(kiro,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);assert.match(readFileSync(join(bare,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);
 const afterSeparation=nonSystem(await catalog('codex',env,workspace));assert.deepEqual(afterSeparation.map(s=>s.name).sort(),expected);report.reEnabledAfterSymlinkCatalog=afterSeparation.map(({name,path})=>({name,path}));report.symlinkSeparated=true;report.foreignPreservedInBothRoots=true;
 report.status='pass';report.nativeVersion=run('codex',['--version']).trim();report.catalog=first;report.repeatedCatalogIdentical=true;report.foreignPreserved=true;report.removedBareNames=oldNames.filter(n=>n!=='foreign');report.candidates=paths.map(p=>({product:p.name,previousTag:specs.find(s=>s[0]===p.name)[2],candidateSha:p.metadata.candidateSha,asset:p.asset.name,assetSha256:p.asset.sha256}));
}catch(error){report.errors=[error.stack];process.exitCode=1;}
finally{report.probeSha256=createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex');report.catalogAdapterSha256=createHash('sha256').update(readFileSync(new URL('./release-native-catalog-adapter.mjs',import.meta.url))).digest('hex');writeFileSync(resolve(process.argv[2]),JSON.stringify(report,null,2)+'\n');rmSync(root,{recursive:true,force:true});}
console.log(JSON.stringify({status:report.status,catalogCount:report.catalog?.length,errors:report.errors}));
