import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,rmSync,readdirSync,openSync,closeSync} from 'node:fs';
import {tmpdir,release,arch} from 'node:os';
import {join,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {isolatedEnvironment} from '/Users/sambiggins/release-work/20261028/grey-worktree/scripts/release-native.mjs';
import {loadPack} from '/Users/sambiggins/release-work/20261028/grey-worktree/scripts/deploy.mjs';
const packs=[['grey-matter','/Users/sambiggins/release-work/20261028/grey-worktree','scripts/deploy.mjs','05792a71c7e936b3ed26a623933bbfa224d7b93c'],['tkt','/Users/sambiggins/release-work/20261028/tkt-worktree','tools/deploy.mjs','a827bb6f264ad2ef73157fd8c0a471cb78e634fe']];
const output=resolve(process.argv[2]);
const temporary=mkdtempSync(join(tmpdir(),'release-bare-')),home=join(temporary,'home'),workspace=join(home,'workspace');mkdirSync(workspace,{recursive:true});
const env={...isolatedEnvironment(home),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),XDG_STATE_HOME:join(home,'.local/state'),DO_NOT_TRACK:'1'};
const profile='(version 1)(allow default)(deny network*)(allow network-outbound (remote ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))';
const checks=[];
function run(binary,args,cwd=workspace){const command=process.platform==='darwin'?['/usr/bin/sandbox-exec',['-p',profile,binary,...args]]:[binary,args];const capture=join(temporary,`command-${checks.length}.stdout`),fd=openSync(capture,'wx');try{execFileSync(command[0],command[1],{env,cwd,encoding:'utf8',timeout:45000,maxBuffer:16*1024*1024,stdio:['ignore',fd,'pipe']});}finally{closeSync(fd);}const stdout=readFileSync(capture,'utf8');checks.push({command:[binary,...args],cwd,exit:0,stdout});return stdout;}
function tree(root){const rows=[];function walk(at){for(const entry of readdirSync(at,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const path=join(at,entry.name);if(entry.isDirectory())walk(path);else if(entry.isFile())rows.push([path.slice(root.length),createHash('sha256').update(readFileSync(path)).digest('hex')]);else throw Error('unexpected nonregular deploy entry '+path);}}walk(root);return rows.filter(([p])=>!p.endsWith('.installed-by-grey-matter.json')&&!p.endsWith('.installed-by-tkt.json'));}
const report={schema:1,kind:'candidate-bare-probe',status:'fail',platform:{os:process.platform,release:release(),arch:arch()},candidateShas:Object.fromEntries(packs.map(([name,,,sha])=>[name,sha])),checks,rows:[],limits:['Physical-root probes do not establish Kiro/Crush native catalogs.','No previous-release or plugin upgrade is claimed by this probe.']};
try {
 for(const [harness,root] of [['kiro',join(home,'.kiro/skills')],['opencode',join(home,'.config/opencode/skills')],['crush-project',join(workspace,'.agents/skills')]]){
  mkdirSync(root,{recursive:true});mkdirSync(join(root,'foreign'));writeFileSync(join(root,'foreign/SKILL.md'),'---\nname: foreign\ndescription: Preserved user fixture\n---\nForeign sentinel\n');
  const expected=['foreign'];
  for(const [name,repo,engine,sha] of packs){assert.equal(run('git',['rev-parse','HEAD'],repo).trim(),sha);const pack=loadPack(repo);expected.push(...pack.skills.map(s=>s.name));
   const args=[join(repo,engine),'--root',root,'--no-agy'];
   const before=tree(root);run(process.execPath,[...args,'--dry-run']);assert.deepEqual(tree(root),before,'dry-run changed bare root');
   run(process.execPath,args);const once=tree(root);run(process.execPath,args);assert.deepEqual(tree(root),once,'second deployment changed payload bytes');
  }
  const names=readdirSync(root).filter(n=>!n.startsWith('.')).sort();assert.deepEqual(names,[...expected].sort());assert.equal(new Set(names).size,53);assert.match(readFileSync(join(root,'foreign/SKILL.md'),'utf8'),/Foreign sentinel/);
  const row={harness,root,names,physicalSkillCount:names.length,foreignPreserved:true,dryRunUnchanged:true,repeatedPayloadUnchanged:true};
  if(harness==='opencode'){
   row.version=run('opencode',['--version']).trim();const catalog=JSON.parse(run('opencode',['debug','skill','--pure']));row.catalog=catalog.map(({name,location})=>({name,location}));
   const loaded=catalog.map(s=>s.name).filter(n=>expected.includes(n));assert.deepEqual(loaded.sort(),[...expected].sort());row.nativeCatalogCount=loaded.length;
  }
  report.rows.push(row);
  rmSync(root,{recursive:true});
 }
 report.status='pass';
}catch(error){report.errors=[error.stack];process.exitCode=1;}
finally{report.toolingSha256=createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex');writeFileSync(output,JSON.stringify(report,null,2)+'\n');rmSync(temporary,{recursive:true,force:true});}
console.log(JSON.stringify({status:report.status,rows:report.rows.map(({harness,physicalSkillCount,nativeCatalogCount})=>({harness,physicalSkillCount,nativeCatalogCount})),errors:report.errors}));
